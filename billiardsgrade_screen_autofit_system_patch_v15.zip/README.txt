Apply these files at the repository root.

What changed:
- Added native Android screen metrics reader (no UI shown in app settings)
- Added AutoFitStage wrapper that scales the gameplay board by the real vertical space left on screen
- Restored settings screen files so no screen-profile controls are shown in app settings
- Tightened header/shot-clock sizing and reduced console camera dominance on short landscape screens

Build commands:
cd android
gradlew clean
cd ..
npx react-native start --reset-cache
npx react-native run-android
