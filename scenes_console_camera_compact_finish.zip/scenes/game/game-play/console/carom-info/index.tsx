import React, {memo, useCallback} from 'react';
import {useWindowDimensions} from 'react-native';
import {Image as RNImage, TextStyle} from 'react-native';
import View from 'components/View';
import Text from 'components/Text';
import Image from 'components/Image';
import Countdown from 'components/Countdown';
import colors from 'configuration/colors';
import {Player} from 'types/player';

import {dims} from 'configuration';
import images from 'assets';
import CaromInfoViewModel, {Props} from './CaromInfoViewModel';
import styles from './styles';
import {getCountryFlagImageUri} from '../../../settings/player/countries';


const isRemoteUri = (value?: string) => /^https?:\/\//i.test(String(value || '').trim());

const getPlayerFlagImageUri = (player?: {countryCode?: string; flag?: string}) => {
  const fromCode = getCountryFlagImageUri(player?.countryCode, 80);
  if (fromCode) {
    return fromCode;
  }

  const rawFlag = String(player?.flag || '').trim();
  return isRemoteUri(rawFlag) ? rawFlag : '';
};

const getPlayerFlagText = (player?: {flag?: string}) => {
  const rawFlag = String(player?.flag || '').trim();
  return isRemoteUri(rawFlag) ? '' : rawFlag;
};

const CaromInfo = (props: Props) => {
  const viewModel = CaromInfoViewModel(props);
  const isLibre = props.gameSettings?.category === 'libre';
  const {width, height} = useWindowDimensions();
  const shortestSide = Math.min(width, height);
  const isHandheldLandscape = width > height && shortestSide < 650 && height <= 820;

  const getTotalPointFont = useCallback(
    (point: number) => {
      const value = Number(point || 0);

      if (!isLibre) {
        return isHandheldLandscape
          ? {
              fontSize: 30,
              lineHeight: 34,
            }
          : {
              fontSize: 40,
              lineHeight: 46,
            };
      }

      if (value >= 1000) {
        return isHandheldLandscape ? {
          fontSize: 18,
          lineHeight: 22,
        } : {
          fontSize: 22,
          lineHeight: 26,
        };
      }

      if (value >= 100) {
        return isHandheldLandscape ? {
          fontSize: 24,
          lineHeight: 28,
        } : {
          fontSize: 30,
          lineHeight: 34,
        };
      }

      return isHandheldLandscape ? {
        fontSize: 30,
        lineHeight: 34,
      } : {
        fontSize: 40,
        lineHeight: 46,
      };
    },
    [isLibre],
  );

  const renderPlayer = useCallback(
    (player: Player, index: number, totalPointStyle: TextStyle) => {
      const totalPointValue = Number(player.totalPoint || 0);
      const totalPointFont = getTotalPointFont(totalPointValue);

      const playerFlag = getPlayerFlagText(player as any);
      const playerFlagImage = getPlayerFlagImageUri(player as any);

      return (
        <View
          style={{backgroundColor: player.color}}
          direction={'row'}
          alignItems={'center'}>
          <View direction={'row'} alignItems={'center'} paddingLeft={isHandheldLandscape ? '6' : '10'}>
            {playerFlagImage || playerFlag ? (
              <View style={styles.flagBadge}>
                {playerFlagImage ? (
                  <RNImage
                    source={{uri: playerFlagImage}}
                    resizeMode="cover"
                    fadeDuration={0}
                    style={{width: '100%', height: '100%', backgroundColor: '#FFFFFF'}}
                  />
                ) : (
                  <Text style={styles.flagText}>{playerFlag}</Text>
                )}
              </View>
            ) : null}

            <View flex={'1'} style={playerFlag ? styles.nameWithFlag : undefined}>
              <Text fontSize={isHandheldLandscape ? 16 : 22} fontWeight={'900'} numberOfLines={1}>
                {player.name.toUpperCase()}
              </Text>
            </View>

            {props.currentPlayerIndex === index ? (
              <Image source={images.game.turn} style={styles.turnImage} />
            ) : (
              <View style={styles.empty} />
            )}

            <View direction={'row'} alignItems={'end'}>
              <View style={styles.totalPointWrapper} paddingHorizontal={'10'}>
                <Text
                  style={totalPointStyle}
                  fontSize={totalPointFont.fontSize}
                  lineHeight={totalPointFont.lineHeight}
                  fontWeight={'bold'}
                  color={colors.white}
                  numberOfLines={1}>
                  {totalPointValue}
                </Text>
              </View>

              <View style={styles.currentTotalPoint} paddingHorizontal={'10'}>
                <Text
                  style={styles.currentPointText}
                  fontSize={isHandheldLandscape ? 24 : 32}
                  lineHeight={isHandheldLandscape ? 28 : 38}
                  fontWeight={'bold'}>
                  {player.proMode?.currentPoint || 0}
                </Text>
              </View>
            </View>
          </View>
        </View>
      );
    },
    [props.currentPlayerIndex, getTotalPointFont, isHandheldLandscape],
  );

  if (!props.gameSettings.mode?.countdownTime) {
    return <View />;
  }

  return (
    <View style={styles.container} direction={'row'} marginTop={isHandheldLandscape ? '6' : '10'}>
      <View flex={'1'}>
        <View
          collapsable={false}
          style={styles.countdownContainer}
          direction={'row'}>
          <View>
            <View
              flex={'1'}
              justify={'center'}
              style={styles.totalTurnWrapper}
              paddingHorizontal={'20'}>
              <Text color={colors.white} fontSize={isHandheldLandscape ? 44 : 56} lineHeight={isHandheldLandscape ? 52 : 70}>
                {Math.max(1, Number(props.totalTurns || 1))}
              </Text>
            </View>
          </View>

          <View flex={'1'}>
            {renderPlayer(viewModel.player0, 0, styles.totalPointText0)}
            {renderPlayer(viewModel.player1, 1, styles.totalPointText1)}
          </View>
        </View>

        <View
          collapsable={false}
          style={styles.countdownContainer}
          direction={'row'}
          alignItems={'center'}>
          <View
            style={styles.countdownWrapper}
            paddingHorizontal={'20'}
            marginLeft={'5'}>
            <Text fontSize={isHandheldLandscape ? 16 : 20} color={colors.white}>
              {props.countdownTime}
            </Text>
          </View>

          <View flex={'1'} direction={'row'}>
            <Countdown
              originalCountdownTime={props.gameSettings.mode?.countdownTime}
              currentCountdownTime={props.countdownTime}
              countdownWidth={dims.screenWidth * (isHandheldLandscape ? 0.24 : 0.28)}
              heightItem={27}
              marginHorizontal={2}
              direction="right-to-left"
              colorMode="threshold"
              yellowThreshold={10}
              redThreshold={5}
            />
          </View>
        </View>
      </View>
    </View>
  );
};

export default memo(CaromInfo);