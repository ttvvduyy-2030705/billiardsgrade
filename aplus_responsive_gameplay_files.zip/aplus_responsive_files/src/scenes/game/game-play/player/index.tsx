import React, {memo, useMemo} from 'react';
import {
  Image,
  StyleSheet,
  TextInput,
  Text as RNText,
  useWindowDimensions,
} from 'react-native';

import View from 'components/View';
import Button from 'components/Button';
import i18n from 'i18n';
import {isPool15FreeGame, isPool15Game, isPoolGame} from 'utils/game';

import PlayerViewModel, {Props} from './PlayerViewModel';

const isEnglish = () => {
  const locale = String(
    (i18n as any)?.locale || (i18n as any)?.language || '',
  ).toLowerCase();
  return locale.startsWith('en');
};

const tr = (vi: string, en: string) => (isEnglish() ? en : vi);

const isRemoteUri = (value: string) =>
  /^https?:\/\//i.test(value) || /^file:\/\//i.test(value);

const GamePlayer = (
  props: Props & {layout?: 'default' | 'poolArena'; compact?: boolean},
) => {
  const viewModel = PlayerViewModel(props);
  const isPoolMode = isPoolGame(props.gameSettings?.category);
  const isPool15Mode = isPool15Game(props.gameSettings?.category);
  const isPool15FreeMode = isPool15FreeGame(props.gameSettings?.category);
  const isActiveCard = !!props.isOnTurn;

  const {width, height, fontScale} = useWindowDimensions();
  const shortestSide = Math.min(width, height);
  const longestSide = Math.max(width, height);
  const isLandscape = width > height;
  const isLargeDisplay = longestSide >= 1600 || shortestSide >= 900;
  const isTabletLandscapeCompact =
    isLandscape && !isLargeDisplay && shortestSide >= 430 && shortestSide <= 900;
  const isPhoneLandscape = isLandscape && shortestSide < 430;
  const useForcedCompact =
    isPhoneLandscape || isTabletLandscapeCompact || shortestSide < 480;

  const isCompactLayout = Boolean(
    props.compact || useForcedCompact || (props.totalPlayers || 2) > 2,
  );

  const isPhoneLandscapeTwoPlayer =
    isLandscape && !isLargeDisplay && (props.totalPlayers || 2) <= 2;

  const isExtraCompactLayout =
    (props.totalPlayers || 2) >= 4 || (!isLargeDisplay && shortestSide <= 430);

  const uiScale = useMemo(() => {
    if (isLargeDisplay) {
      return 1;
    }

    const base = Math.max(0.72, Math.min(1, shortestSide / 900));
    return Math.max(0.7, Math.min(1, base / Math.min(fontScale || 1, 1.15)));
  }, [fontScale, isLargeDisplay, shortestSide]);

  const isCaromMode = !isPoolMode;
  const isLibreMode = props.gameSettings?.category === 'libre';
  const totalPointValue = Number(props.player.totalPoint || 0);
  const rawPlayerColor = String((props.player as any)?.color || '').trim();
  const useColoredPanel = Boolean(rawPlayerColor) && isCaromMode;
  const playerPanelColor = useColoredPanel ? rawPlayerColor : '#000000';
  const primaryTextColor = useColoredPanel ? '#111111' : '#FFFFFF';
  const secondaryTextColor = useColoredPanel
    ? 'rgba(17,17,17,0.72)'
    : '#FFFFFF';
  const inactiveTextColor = useColoredPanel
    ? 'rgba(17,17,17,0.52)'
    : '#8B8D95';

  const panelDynamicStyle = useColoredPanel
    ? {backgroundColor: playerPanelColor, borderColor: 'rgba(17,17,17,0.28)'}
    : {backgroundColor: '#000000', borderColor: '#FF1818'};

  const textColorStyle = {color: primaryTextColor};
  const inactivePlaceholderColor = inactiveTextColor;

  const scoreLayerDynamicStyle = isCaromMode
    ? isPhoneLandscapeTwoPlayer
      ? styles.scoreLayerCaromPhoneLandscape
      : isExtraCompactLayout
      ? styles.scoreLayerCaromExtraCompact
      : isCompactLayout
      ? styles.scoreLayerCaromCompact
      : styles.scoreLayerCarom
    : isPhoneLandscapeTwoPlayer
    ? styles.scoreLayerPhoneLandscape
    : isExtraCompactLayout
    ? styles.scoreLayerExtraCompact
    : isCompactLayout
    ? styles.scoreLayerCompact
    : undefined;

  const scoreTextDynamicStyle = isCaromMode
    ? isPhoneLandscapeTwoPlayer
      ? styles.scoreTextCaromPhoneLandscape
      : isExtraCompactLayout
      ? styles.scoreTextCaromExtraCompact
      : isCompactLayout
      ? styles.scoreTextCaromCompact
      : styles.scoreTextCarom
    : isPhoneLandscapeTwoPlayer
    ? styles.scoreTextPhoneLandscape
    : isExtraCompactLayout
    ? styles.scoreTextExtraCompact
    : isCompactLayout
    ? styles.scoreTextCompact
    : undefined;

  const libreScoreTextStyle = useMemo(() => {
    if (!isLibreMode || totalPointValue < 100) {
      return undefined;
    }

    if (isPhoneLandscapeTwoPlayer) {
      return totalPointValue >= 1000
        ? styles.scoreTextLibre4DigitsPhoneLandscape
        : styles.scoreTextLibre3DigitsPhoneLandscape;
    }

    if (isExtraCompactLayout) {
      return totalPointValue >= 1000
        ? styles.scoreTextLibre4DigitsExtraCompact
        : styles.scoreTextLibre3DigitsExtraCompact;
    }

    if (isCompactLayout) {
      return totalPointValue >= 1000
        ? styles.scoreTextLibre4DigitsCompact
        : styles.scoreTextLibre3DigitsCompact;
    }

    return totalPointValue >= 1000
      ? styles.scoreTextLibre4Digits
      : styles.scoreTextLibre3Digits;
  }, [
    isLibreMode,
    totalPointValue,
    isPhoneLandscapeTwoPlayer,
    isExtraCompactLayout,
    isCompactLayout,
  ]);

  const extraTimeTurns = Math.max(
    0,
    Number((props.player as any)?.proMode?.extraTimeTurns ?? 0),
  );

  const showAddTime = extraTimeTurns > 0 && !isPool15Mode;

  const addTimeButtons = useMemo(() => {
    return Array.from({length: extraTimeTurns}, (_, index) => index);
  }, [extraTimeTurns]);

  const rawFlag = String((props.player as any)?.flag || '').trim();
  const playerFlagUri = isRemoteUri(rawFlag) ? rawFlag : '';
  const playerFlagText = playerFlagUri ? '' : rawFlag;

  return (
    <View
      style={[
        styles.panel,
        !isLargeDisplay && styles.panelScaled,
        isPhoneLandscapeTwoPlayer ? styles.panelPhoneLandscape : undefined,
        panelDynamicStyle,
        isActiveCard ? styles.panelActive : styles.panelInactive,
      ]}>
      <View style={[styles.nameRow, isCompactLayout && styles.nameRowCompact]}>
        {playerFlagUri ? (
          <View
            style={[
              styles.flagBadge,
              isCompactLayout && styles.flagBadgeCompact,
              isActiveCard ? styles.flagBadgeActive : styles.flagBadgeInactive,
            ]}>
            <Image
              source={{uri: playerFlagUri}}
              style={styles.flagImage}
              resizeMode="contain"
            />
          </View>
        ) : playerFlagText ? (
          <View
            style={[
              styles.flagBadge,
              isCompactLayout && styles.flagBadgeCompact,
              isActiveCard ? styles.flagBadgeActive : styles.flagBadgeInactive,
            ]}>
            <RNText
              style={[
                styles.flagText,
                isCompactLayout && styles.flagTextCompact,
                !isActiveCard && styles.flagTextInactive,
              ]}>
              {playerFlagText}
            </RNText>
          </View>
        ) : null}

        {viewModel.nameEditable ? (
          <TextInput
            value={viewModel.draftName}
            onChangeText={viewModel.onChangeDraftName}
            autoFocus
            onBlur={viewModel.onCommitName}
            onSubmitEditing={viewModel.onCommitName}
            blurOnSubmit
            numberOfLines={1}
            style={[
              styles.nameInput,
              {fontSize: Math.round(42 * uiScale), lineHeight: Math.round(48 * uiScale)},
              (playerFlagUri || playerFlagText) && styles.nameTextWithFlag,
              isCompactLayout && styles.nameInputCompact,
              textColorStyle,
              !isActiveCard && styles.nameTextInactive,
            ]}
            placeholderTextColor={inactivePlaceholderColor}
          />
        ) : (
          <RNText
            numberOfLines={2}
            adjustsFontSizeToFit
            minimumFontScale={0.72}
            style={[
              styles.nameText,
              {fontSize: Math.round(42 * uiScale), lineHeight: Math.round(48 * uiScale)},
              (playerFlagUri || playerFlagText) && styles.nameTextWithFlag,
              isCompactLayout && styles.nameTextCompact,
              textColorStyle,
              !isActiveCard && styles.nameTextInactive,
            ]}>
            {props.player.name}
          </RNText>
        )}

        <Button
          onPress={viewModel.onToggleEditName}
          style={[
            styles.editButton,
            isCompactLayout && styles.editButtonCompact,
            !isActiveCard && styles.editButtonInactive,
          ]}>
          <RNText
            style={[
              styles.editText,
              isCompactLayout && styles.editTextCompact,
              textColorStyle,
              !isActiveCard && styles.editTextInactive,
            ]}>
            ✎
          </RNText>
        </Button>
      </View>

      <View
        direction={'row'}
        style={[
          styles.plusMinusRow,
          isCompactLayout && styles.plusMinusRowCompact,
          !isActiveCard && styles.controlsRowInactive,
        ]}>
        <Button
          style={[styles.stepButton, isCompactLayout && styles.stepButtonCompact]}
          onPress={viewModel.onDecreasePoint}>
          <RNText
            style={[
              styles.stepButtonText,
              {fontSize: Math.round((isCompactLayout ? 26 : 30) * uiScale)},
              isCompactLayout && styles.stepButtonTextCompact,
            ]}>
            −
          </RNText>
        </Button>

        <Button
          style={[styles.stepButton, isCompactLayout && styles.stepButtonCompact]}
          onPress={viewModel.onIncreasePoint}>
          <RNText
            style={[
              styles.stepButtonText,
              {fontSize: Math.round((isCompactLayout ? 26 : 30) * uiScale)},
              isCompactLayout && styles.stepButtonTextCompact,
            ]}>
            ＋
          </RNText>
        </Button>
      </View>

      {viewModel.showProMode ? (
        <View
          direction={'row'}
          style={[
            styles.statsRow,
            isCompactLayout && styles.statsRowCompact,
            !isActiveCard && styles.statsRowInactive,
          ]}>
          <View style={styles.statBlock}>
            <RNText
              style={[
                styles.statLabel,
                isCompactLayout && styles.statLabelCompact,
                {color: secondaryTextColor},
              ]}>
              High run
            </RNText>
            <RNText
              style={[
                styles.statValue,
                isCompactLayout && styles.statValueCompact,
                textColorStyle,
              ]}>
              {viewModel.highestRate}
            </RNText>
          </View>

          <View style={styles.statBlock}>
            <RNText
              style={[
                styles.statLabel,
                isCompactLayout && styles.statLabelCompact,
                {color: secondaryTextColor},
              ]}>
              Average
            </RNText>
            <RNText
              style={[
                styles.statValue,
                isCompactLayout && styles.statValueCompact,
                textColorStyle,
              ]}>
              {viewModel.averagePoint}
            </RNText>
          </View>
        </View>
      ) : null}

      <View
        style={[
          styles.scoreLayer,
          scoreLayerDynamicStyle,
          !isActiveCard && styles.scoreLayerInactive,
          isPool15FreeMode && styles.scoreLayerWithScoredBalls,
        ]}
        pointerEvents="none">
        <RNText
          numberOfLines={1}
          adjustsFontSizeToFit
          minimumFontScale={0.5}
          style={[
            styles.scoreText,
            scoreTextDynamicStyle,
            libreScoreTextStyle,
            textColorStyle,
          ]}>
          {totalPointValue}
        </RNText>
      </View>

      {showAddTime ? (
        <View
          style={[
            styles.addTimeStack,
            isCompactLayout && styles.addTimeStackCompact,
            !isActiveCard && styles.addTimeStackInactive,
          ]}>
          {addTimeButtons.map(index => (
            <Button
              key={`extra-time-${index}`}
              onPress={isActiveCard ? props.onPressGiveMoreTime : undefined}
              style={[
                styles.addTimeButton,
                isCompactLayout && styles.addTimeButtonCompact,
                !isActiveCard && styles.addTimeButtonInactive,
              ]}>
              <RNText
                style={[
                  styles.addTimeText,
                  isCompactLayout && styles.addTimeTextCompact,
                  !isActiveCard && styles.addTimeTextInactive,
                ]}>
                ◷+
              </RNText>
            </Button>
          ))}
        </View>
      ) : null}

      {isPool15FreeMode && (props.player.scoredBalls || []).length > 0 ? (
        <View
          style={[
            styles.scoredBallStack,
            isCompactLayout && styles.scoredBallStackCompact,
            !isActiveCard && styles.scoredBallStackInactive,
          ]}>
          {(props.player.scoredBalls || []).map((ball, index) => {
            const isBlackBall = ball.number === 8;
            const textColor = isBlackBall ? '#FFFFFF' : '#111111';

            return (
              <View
                key={`player-scored-ball-${ball.number}-${index}`}
                style={[
                  styles.scoredBallItem,
                  {
                    backgroundColor: ball.cut ? '#FFFFFF' : ball.color,
                    borderColor: ball.color,
                  },
                ]}>
                {ball.cut ? (
                  <View
                    style={[
                      styles.scoredBallStripe,
                      {backgroundColor: ball.color},
                    ]}
                  />
                ) : null}
                <RNText
                  style={[
                    styles.scoredBallText,
                    {color: ball.cut ? '#111111' : textColor},
                  ]}>
                  {ball.number}
                </RNText>
              </View>
            );
          })}
        </View>
      ) : null}

      {isActiveCard ? (
        <Button
          onPress={() => viewModel.onEndTurn()}
          style={[
            styles.playingBadge,
            isCompactLayout && styles.playingBadgeCompact,
            styles.playingBadgeActive,
          ]}>
          <RNText
            style={[
              styles.playingText,
              isCompactLayout && styles.playingTextCompact,
              styles.playingTextActive,
            ]}>
            {tr('Đang đánh', 'Playing')}
          </RNText>
        </Button>
      ) : (
        <View
          style={[
            styles.playingBadge,
            isCompactLayout && styles.playingBadgeCompact,
            styles.playingBadgeInactive,
          ]}>
          <RNText
            style={[
              styles.playingText,
              isCompactLayout && styles.playingTextCompact,
              styles.playingTextInactive,
            ]}>
            {tr('Đang đánh', 'Playing')}
          </RNText>
        </View>
      )}

      <View
        direction={'row'}
        alignItems={'center'}
        style={[
          styles.violateWrap,
          isCompactLayout && styles.violateWrapCompact,
          !isActiveCard && styles.violateWrapInactive,
        ]}>
        <View
          style={[
            styles.violateCircle,
            isCompactLayout && styles.violateCircleCompact,
            !isActiveCard && styles.violateCircleInactive,
          ]}>
          <RNText
            style={[
              styles.violateX,
              isCompactLayout && styles.violateXCompact,
              !isActiveCard && styles.violateXInactive,
            ]}>
            ×
          </RNText>
        </View>
        <RNText
          style={[
            styles.violateCount,
            isCompactLayout && styles.violateCountCompact,
            textColorStyle,
            !isActiveCard && styles.violateCountInactive,
          ]}>
          {props.player.violate || 0}
        </RNText>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  panel: {
    flex: 1,
    borderRadius: 26,
    borderWidth: 1.4,
    borderColor: '#FF1818',
    backgroundColor: '#000000',
    paddingHorizontal: 18,
    paddingTop: 18,
    paddingBottom: 18,
    overflow: 'hidden',
  },
  panelScaled: {
    paddingHorizontal: 12,
    paddingTop: 12,
    paddingBottom: 12,
    borderRadius: 20,
  },
  panelActive: {
    opacity: 1,
  },
  panelInactive: {
    opacity: 0.52,
  },
  panelPhoneLandscape: {
    paddingHorizontal: 10,
    paddingTop: 10,
    paddingBottom: 10,
    borderRadius: 18,
  },
  nameRow: {
    minHeight: 62,
    flexDirection: 'row',
    alignItems: 'center',
  },
  nameRowCompact: {
    minHeight: 46,
  },
  flagBadge: {
    width: 112,
    height: 76,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
    paddingHorizontal: 4,
    backgroundColor: '#FFFFFF',
    borderWidth: 1.4,
    borderColor: 'rgba(255,255,255,0.92)',
    overflow: 'hidden',
  },
  flagBadgeCompact: {
    width: 76,
    height: 50,
    marginRight: 10,
  },
  flagBadgeActive: {
    opacity: 1,
  },
  flagBadgeInactive: {
    opacity: 0.78,
  },
  flagImage: {
    width: '100%',
    height: '100%',
  },
  flagText: {
    width: '100%',
    fontSize: 52,
    lineHeight: 56,
    textAlign: 'center',
    includeFontPadding: false,
  },
  flagTextCompact: {
    fontSize: 34,
    lineHeight: 36,
  },
  flagTextInactive: {
    opacity: 0.92,
  },
  nameText: {
    flex: 1,
    color: '#FFFFFF',
    fontWeight: '900',
    textAlign: 'center',
  },
  nameTextWithFlag: {
    textAlign: 'left',
  },
  nameTextCompact: {},
  nameInput: {
    flex: 1,
    color: '#FFFFFF',
    fontWeight: '900',
    textAlign: 'center',
    paddingVertical: 0,
  },
  nameInputCompact: {},
  nameTextInactive: {
    opacity: 0.9,
  },
  editButton: {
    width: 36,
    height: 36,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 6,
  },
  editButtonCompact: {
    width: 28,
    height: 28,
  },
  editButtonInactive: {
    opacity: 0.55,
  },
  editText: {
    color: '#FFFFFF',
    fontSize: 22,
    lineHeight: 22,
    fontWeight: '700',
    textAlign: 'center',
    includeFontPadding: false,
  },
  editTextCompact: {
    fontSize: 16,
    lineHeight: 16,
  },
  editTextInactive: {
    opacity: 0.9,
  },
  plusMinusRow: {
    marginTop: 18,
    justifyContent: 'space-between',
    gap: 14,
  },
  plusMinusRowCompact: {
    marginTop: 10,
    gap: 10,
  },
  controlsRowInactive: {
    opacity: 0.7,
  },
  stepButton: {
    flex: 1,
    minHeight: 46,
    borderRadius: 999,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepButtonCompact: {
    minHeight: 36,
  },
  stepButtonText: {
    color: '#000000',
    fontWeight: '700',
    includeFontPadding: false,
  },
  stepButtonTextCompact: {},
  statsRow: {
    marginTop: 16,
    justifyContent: 'space-between',
    gap: 12,
  },
  statsRowCompact: {
    marginTop: 10,
    gap: 10,
  },
  statsRowInactive: {
    opacity: 0.7,
  },
  statBlock: {
    flex: 1,
    alignItems: 'center',
  },
  statLabel: {
    fontSize: 16,
    lineHeight: 18,
    fontWeight: '500',
  },
  statLabelCompact: {
    fontSize: 12,
    lineHeight: 14,
  },
  statValue: {
    marginTop: 6,
    fontSize: 22,
    lineHeight: 24,
    fontWeight: '700',
  },
  statValueCompact: {
    marginTop: 4,
    fontSize: 16,
    lineHeight: 18,
  },
  scoreLayer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 0,
  },
  scoreLayerCompact: {
    paddingVertical: 4,
  },
  scoreLayerExtraCompact: {
    paddingVertical: 2,
  },
  scoreLayerPhoneLandscape: {
    paddingVertical: 0,
  },
  scoreLayerCarom: {
    paddingVertical: 4,
  },
  scoreLayerCaromCompact: {
    paddingVertical: 2,
  },
  scoreLayerCaromExtraCompact: {
    paddingVertical: 0,
  },
  scoreLayerCaromPhoneLandscape: {
    paddingVertical: 0,
  },
  scoreLayerInactive: {
    opacity: 0.88,
  },
  scoreLayerWithScoredBalls: {
    paddingRight: 44,
  },
  scoreText: {
    color: '#FFFFFF',
    fontWeight: '900',
    fontSize: 230,
    lineHeight: 230,
    textAlign: 'center',
    includeFontPadding: false,
  },
  scoreTextCompact: {
    fontSize: 165,
    lineHeight: 165,
  },
  scoreTextExtraCompact: {
    fontSize: 135,
    lineHeight: 135,
  },
  scoreTextPhoneLandscape: {
    fontSize: 150,
    lineHeight: 150,
  },
  scoreTextCarom: {
    fontSize: 230,
    lineHeight: 230,
  },
  scoreTextCaromCompact: {
    fontSize: 170,
    lineHeight: 170,
  },
  scoreTextCaromExtraCompact: {
    fontSize: 140,
    lineHeight: 140,
  },
  scoreTextCaromPhoneLandscape: {
    fontSize: 150,
    lineHeight: 150,
  },
  scoreTextLibre3Digits: {
    fontSize: 190,
    lineHeight: 190,
  },
  scoreTextLibre4Digits: {
    fontSize: 150,
    lineHeight: 150,
  },
  scoreTextLibre3DigitsCompact: {
    fontSize: 150,
    lineHeight: 150,
  },
  scoreTextLibre4DigitsCompact: {
    fontSize: 120,
    lineHeight: 120,
  },
  scoreTextLibre3DigitsExtraCompact: {
    fontSize: 128,
    lineHeight: 128,
  },
  scoreTextLibre4DigitsExtraCompact: {
    fontSize: 104,
    lineHeight: 104,
  },
  scoreTextLibre3DigitsPhoneLandscape: {
    fontSize: 132,
    lineHeight: 132,
  },
  scoreTextLibre4DigitsPhoneLandscape: {
    fontSize: 106,
    lineHeight: 106,
  },
  addTimeStack: {
    position: 'absolute',
    right: 12,
    top: '38%',
    gap: 8,
  },
  addTimeStackCompact: {
    right: 8,
    gap: 6,
  },
  addTimeStackInactive: {
    opacity: 0.7,
  },
  addTimeButton: {
    width: 42,
    height: 42,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.65)',
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  addTimeButtonCompact: {
    width: 34,
    height: 34,
  },
  addTimeButtonInactive: {
    opacity: 0.65,
  },
  addTimeText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '900',
  },
  addTimeTextCompact: {
    fontSize: 12,
  },
  addTimeTextInactive: {
    opacity: 0.92,
  },
  scoredBallStack: {
    position: 'absolute',
    right: 10,
    top: 120,
    gap: 6,
    alignItems: 'center',
  },
  scoredBallStackCompact: {
    top: 92,
    gap: 4,
  },
  scoredBallStackInactive: {
    opacity: 0.8,
  },
  scoredBallItem: {
    width: 26,
    height: 26,
    borderRadius: 13,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  scoredBallStripe: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: '100%',
    height: '38%',
    marginTop: '31%',
  },
  scoredBallText: {
    fontSize: 11,
    lineHeight: 12,
    fontWeight: '900',
    includeFontPadding: false,
  },
  playingBadge: {
    marginTop: 12,
    minHeight: 62,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#1C1C20',
  },
  playingBadgeCompact: {
    minHeight: 44,
    marginTop: 8,
    borderRadius: 14,
  },
  playingBadgeActive: {
    backgroundColor: '#1A1416',
  },
  playingBadgeInactive: {
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  playingText: {
    fontSize: 28,
    lineHeight: 30,
    fontWeight: '900',
  },
  playingTextCompact: {
    fontSize: 20,
    lineHeight: 22,
  },
  playingTextActive: {
    color: '#FF3844',
  },
  playingTextInactive: {
    color: '#FFFFFF',
    opacity: 0.45,
  },
  violateWrap: {
    position: 'absolute',
    right: 10,
    bottom: 10,
    gap: 6,
  },
  violateWrapCompact: {
    right: 8,
    bottom: 8,
    gap: 4,
  },
  violateWrapInactive: {
    opacity: 0.78,
  },
  violateCircle: {
    width: 52,
    height: 52,
    borderRadius: 999,
    backgroundColor: '#FF2A32',
    alignItems: 'center',
    justifyContent: 'center',
  },
  violateCircleCompact: {
    width: 42,
    height: 42,
  },
  violateCircleInactive: {
    backgroundColor: 'rgba(255,255,255,0.14)',
  },
  violateX: {
    color: '#FFFFFF',
    fontSize: 34,
    lineHeight: 34,
    fontWeight: '900',
    includeFontPadding: false,
  },
  violateXCompact: {
    fontSize: 26,
    lineHeight: 26,
  },
  violateXInactive: {
    opacity: 0.82,
  },
  violateCount: {
    color: '#FFFFFF',
    textAlign: 'right',
    fontSize: 18,
    fontWeight: '700',
  },
  violateCountCompact: {
    fontSize: 14,
  },
  violateCountInactive: {
    opacity: 0.8,
  },
});

export default memo(GamePlayer);
