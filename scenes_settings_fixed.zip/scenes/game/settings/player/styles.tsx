import {StyleSheet} from 'react-native';

import colors from 'configuration/colors';
import {LayoutPreset} from 'scenes/game/useAdaptiveLayout';

export const createStyles = (adaptive: {
  s: (value: number) => number;
  fs: (value: number) => number;
  layoutPreset: LayoutPreset;
}) => {
  const {s, fs, layoutPreset} = adaptive;
  const isPhone = layoutPreset === 'phone';

  return StyleSheet.create({
    container: {
      paddingBottom: s(2),
    },
    mainTitle: {
      color: '#FFFFFF',
      fontSize: fs(isPhone ? 14 : 16),
      fontWeight: '800',
      marginBottom: s(10),
    },
    topControls: {
      paddingTop: 0,
      marginBottom: s(6),
    },
    controlRow: {
      flexDirection: 'row',
      alignItems: 'flex-start',
      marginBottom: s(8),
    },
    controlRowCompact: {
      marginBottom: s(7),
    },
    controlLabel: {
      width: s(isPhone ? 60 : 72),
      color: '#FFFFFF',
      fontSize: fs(isPhone ? 12 : 13),
      fontWeight: '700',
      marginRight: s(8),
      paddingTop: s(6),
    },
    controlOptionsRow: {
      flex: 1,
      flexDirection: 'row',
      flexWrap: 'wrap',
      alignItems: 'center',
    },
    selectorButton: {
      minWidth: s(isPhone ? 32 : 36),
      minHeight: s(isPhone ? 28 : 31),
      paddingHorizontal: s(isPhone ? 10 : 11),
      paddingVertical: s(4),
      marginRight: s(6),
      marginBottom: s(6),
      borderRadius: s(13),
      borderWidth: 1,
      borderColor: 'rgba(255,255,255,0.28)',
      backgroundColor: '#4A4A4A',
      alignItems: 'center',
      justifyContent: 'center',
    },
    selectorButtonActive: {
      backgroundColor: '#E11D25',
      borderColor: '#E11D25',
    },
    selectorButtonPressed: {
      opacity: 0.88,
    },
    selectorButtonText: {
      color: colors.white,
      fontSize: fs(isPhone ? 12 : 13),
      fontWeight: '600',
    },
    selectorButtonTextActive: {
      color: colors.white,
      fontWeight: '700',
    },
    playerList: {
      paddingTop: 0,
    },
    playerCard: {
      borderRadius: s(14),
      paddingHorizontal: s(8),
      paddingVertical: s(8),
      marginBottom: s(8),
      borderWidth: 1,
      borderColor: 'rgba(255,255,255,0.08)',
      flexDirection: 'row',
      alignItems: 'center',
    },
    playerCardPool: {
      backgroundColor: '#4A4A4A',
      borderColor: 'rgba(255,48,48,0.38)',
    },
    playerCardRight: {
      flex: 1,
      justifyContent: 'center',
      marginLeft: s(8),
      minWidth: 0,
    },
    playerCardTop: {
      flexDirection: 'row',
      alignItems: 'center',
      minHeight: s(34),
    },
    avatarText: {
      color: '#1A1A1A',
      fontSize: fs(22),
      lineHeight: fs(24),
      fontWeight: '700',
      textAlign: 'center',
      textAlignVertical: 'center',
      includeFontPadding: false,
    },
    avatarTextLight: {
      color: colors.white,
    },
    nameInput: {
      flex: 1,
      height: s(34),
      borderRadius: s(10),
      backgroundColor: '#F5F0DA',
      paddingHorizontal: s(10),
      paddingVertical: 0,
      color: '#1A1A1A',
      fontSize: fs(isPhone ? 12.5 : 13.5),
      lineHeight: fs(16),
      fontWeight: '500',
      textAlignVertical: 'center',
    },
    nameInputPool: {
      backgroundColor: '#D9D9D9',
      color: '#1B1B1B',
    },
    scoreRow: {
      flexDirection: 'row',
      alignItems: 'center',
      borderRadius: s(10),
      backgroundColor: '#F5F0DA',
      overflow: 'hidden',
      marginTop: s(8),
    },
    scoreRowPool: {
      backgroundColor: '#6A6A6A',
    },
    scoreItem: {
      flex: 1,
      minHeight: s(isPhone ? 22 : 24),
      alignItems: 'center',
      justifyContent: 'center',
      borderRightWidth: 1,
      borderRightColor: 'rgba(0,0,0,0.12)',
    },
    scoreItemPool: {
      borderRightColor: 'rgba(255,255,255,0.18)',
    },
    scoreItemCenter: {
      backgroundColor: '#EEE6C5',
    },
    scoreItemCenterPool: {
      backgroundColor: '#E11D25',
    },
    scoreText: {
      color: '#202020',
      fontSize: fs(isPhone ? 10.5 : 11.5),
      fontWeight: '500',
    },
    scoreTextPool: {
      color: colors.white,
    },
    scoreTextCenter: {
      fontWeight: '700',
    },
    countryModalOverlay: {
      flex: 1,
      backgroundColor: 'rgba(0,0,0,0.45)',
      justifyContent: 'center',
      alignItems: 'center',
      paddingHorizontal: s(20),
    },
    countryModalCard: {
      width: '100%',
      maxWidth: s(420),
      maxHeight: '72%',
      backgroundColor: '#1F1F1F',
      borderRadius: s(14),
      borderWidth: 1,
      borderColor: 'rgba(255,0,0,0.28)',
      padding: s(14),
    },
    countryModalTitle: {
      color: '#FFFFFF',
      fontSize: fs(16),
      fontWeight: '700',
      marginBottom: s(10),
    },
    countrySearchInput: {
      height: s(42),
      borderRadius: s(10),
      backgroundColor: '#2B2B2B',
      borderWidth: 1,
      borderColor: 'rgba(255,255,255,0.08)',
      color: '#FFFFFF',
      paddingHorizontal: s(12),
      marginBottom: s(10),
    },
    countryList: {
      flexGrow: 0,
    },
    countryItem: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: s(10),
      paddingHorizontal: s(8),
      borderRadius: s(10),
    },
    countryItemPressed: {
      backgroundColor: 'rgba(255,255,255,0.06)',
    },
    countryFlag: {
      width: s(28),
      fontSize: fs(20),
      marginRight: s(10),
      textAlign: 'center',
    },
    countryName: {
      color: '#FFFFFF',
      fontSize: fs(15),
      flex: 1,
    },
    countryEmptyText: {
      color: '#B8B8B8',
      fontSize: fs(14),
      textAlign: 'center',
      paddingVertical: s(20),
    },
  });
};

export default createStyles;
