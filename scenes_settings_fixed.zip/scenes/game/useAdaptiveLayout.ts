import {useMemo} from 'react';
import {PixelRatio, useWindowDimensions} from 'react-native';

export type LayoutPreset = 'phone' | 'tablet' | 'wideTablet' | 'tv';
export type WidthClass = 'compact' | 'medium' | 'expanded';

const clamp = (value: number, min: number, max: number) =>
  Math.min(Math.max(value, min), max);

const round = (value: number) => PixelRatio.roundToNearestPixel(value);

export default function useAdaptiveLayout() {
  const {width, height, fontScale} = useWindowDimensions();

  return useMemo(() => {
    const shortSide = Math.min(width, height);
    const longSide = Math.max(width, height);
    const aspectRatio = width / Math.max(height, 1);
    const isLandscape = width >= height;

    const widthClass: WidthClass =
      width >= 1280 ? 'expanded' : width >= 900 ? 'medium' : 'compact';

    let layoutPreset: LayoutPreset = 'phone';
    if (width >= 1680 || shortSide >= 960) {
      layoutPreset = 'tv';
    } else if (isLandscape && width >= 1180) {
      layoutPreset = 'wideTablet';
    } else if ((isLandscape && width >= 900) || shortSide >= 700) {
      layoutPreset = 'tablet';
    }

    const baseScale = clamp(width / 1180, 0.88, 1.22);
    const aspectBonus = isLandscape ? clamp((aspectRatio - 1.4) * 0.12, -0.03, 0.06) : 0;
    const sizeScale = clamp(baseScale + aspectBonus, 0.88, 1.26);
    const safeFontScale = clamp(fontScale || 1, 1, 1.15);

    const s = (value: number) => round(value * sizeScale);
    const fs = (value: number) => round(clamp((value * sizeScale) / safeFontScale, value * 0.92, value * 1.24));

    return {
      width,
      height,
      shortSide,
      longSide,
      aspectRatio,
      isLandscape,
      widthClass,
      layoutPreset,
      sizeScale,
      s,
      fs,
    };
  }, [width, height, fontScale]);
}
