import {StyleSheet} from 'react-native';

import colors from 'configuration/colors';

import {AdaptiveLayout} from '../useAdaptiveLayout';

const createStyles = (a: AdaptiveLayout) => {
  const stackPanels = a.widthClass === 'compact' && !a.isLandscape;
  const panelGap = a.layoutPreset === 'phone' ? a.s(8) : a.s(10);

  return StyleSheet.create({
    screen: {
      flex: 1,
      backgroundColor: '#000000',
      paddingHorizontal: a.layoutPreset === 'phone' ? a.s(10) : a.s(14),
      paddingTop: a.layoutPreset === 'phone' ? a.s(8) : a.s(10),
      paddingBottom: a.layoutPreset === 'phone' ? a.s(8) : a.s(10),
    },
    headerGlow: {
      position: 'relative',
      minHeight: a.layoutPreset === 'phone' ? a.s(52) : a.s(56),
      borderRadius: a.s(22),
      borderWidth: 1.1,
      borderColor: 'rgba(255, 52, 52, 0.24)',
      backgroundColor: '#050505',
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      paddingHorizontal: a.layoutPreset === 'phone' ? a.s(12) : a.s(14),
      shadowColor: '#FF1414',
      shadowOpacity: 0.36,
      shadowRadius: a.s(16),
      shadowOffset: {width: 0, height: a.s(6)},
      elevation: 8,
    },
    headerBackButton: {
      position: 'absolute',
      left: a.layoutPreset === 'phone' ? a.s(12) : a.s(14),
      top: 0,
      bottom: 0,
      justifyContent: 'center',
      zIndex: 2,
    },
    headerBackFrame: {
      height: a.layoutPreset === 'phone' ? a.s(40) : a.s(42),
      minWidth: a.layoutPreset === 'phone' ? a.s(100) : a.s(108),
      paddingHorizontal: a.layoutPreset === 'phone' ? a.s(12) : a.s(14),
      borderRadius: a.s(14),
      borderWidth: 1.1,
      borderColor: 'rgba(255, 52, 52, 0.24)',
      backgroundColor: '#070707',
      justifyContent: 'center',
      shadowColor: '#FF1414',
      shadowOpacity: 0.18,
      shadowRadius: a.s(10),
      shadowOffset: {width: 0, height: a.s(4)},
      elevation: 6,
      transform: [{skewX: '-16deg'}],
    },
    headerBackInner: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      transform: [{skewX: '16deg'}],
    },
    headerBackArrow: {
      color: '#FFFFFF',
      fontSize: a.fs(20, 0.9, 1.04),
      fontWeight: '900',
      marginRight: a.s(10),
    },
    headerBackLogoImage: {
      width: a.layoutPreset === 'phone' ? a.s(66) : a.s(72),
      height: a.layoutPreset === 'phone' ? a.s(22) : a.s(24),
    },
    headerTitleWrap: {
      position: 'absolute',
      left: 0,
      right: 0,
      alignItems: 'center',
      justifyContent: 'center',
      paddingHorizontal: stackPanels ? a.s(110) : a.s(132),
      pointerEvents: 'none',
    },
    logoButton: {
      position: 'absolute',
      left: a.s(14),
      top: 0,
      bottom: 0,
      width: a.s(100),
      justifyContent: 'center',
      alignItems: 'flex-start',
      paddingVertical: 4,
      zIndex: 2,
    },
    logoImage: {
      width: a.s(82),
      height: a.s(28),
    },
    headerTitle: {
      flexShrink: 1,
      color: '#FFFFFF',
      textAlign: 'center',
      fontSize: a.fs(a.layoutPreset === 'phone' ? 18 : 22, 0.9, 1),
      fontWeight: '800',
      letterSpacing: 0.2,
      textShadowColor: 'rgba(0,0,0,0.35)',
      textShadowOffset: {width: 0, height: 0},
      textShadowRadius: 1.2,
    },
    headerSpacer: {
      width: 0,
    },
    contentRow: {
      flex: 1,
      flexDirection: stackPanels ? 'column' : 'row',
      marginTop: a.layoutPreset === 'phone' ? a.s(8) : a.s(12),
      minHeight: 0,
    },
    panelShell: {
      flex: 1,
      minHeight: 0,
      borderRadius: a.s(22),
      borderWidth: 1,
      borderColor: 'rgba(255, 42, 42, 0.18)',
      backgroundColor: '#050505',
      paddingTop: a.layoutPreset === 'phone' ? a.s(8) : a.s(10),
      paddingHorizontal: a.layoutPreset === 'phone' ? a.s(8) : a.s(10),
      paddingBottom: a.layoutPreset === 'phone' ? a.s(8) : a.s(8),
      shadowColor: '#FF1414',
      shadowOpacity: 0.22,
      shadowRadius: a.s(14),
      shadowOffset: {width: 0, height: a.s(4)},
      elevation: 7,
    },
    leftPanel: {
      marginRight: stackPanels ? 0 : panelGap,
      marginBottom: stackPanels ? panelGap : 0,
    },
    rightPanel: {
      marginLeft: stackPanels ? 0 : panelGap,
    },
    panelHeader: {
      borderBottomWidth: 1.1,
      borderBottomColor: '#FF1F26',
      paddingBottom: a.layoutPreset === 'phone' ? a.s(6) : a.s(7),
      marginBottom: a.layoutPreset === 'phone' ? a.s(6) : a.s(6),
    },
    panelHeaderText: {
      alignSelf: 'flex-start',
      color: '#FFFFFF',
      fontSize: a.fs(a.layoutPreset === 'tv' ? 18 : 13.5, 0.94, 1.02),
      fontWeight: '800',
      letterSpacing: 0.2,
      textShadowColor: 'rgba(0,0,0,0.35)',
      textShadowOffset: {width: 0, height: 0},
      textShadowRadius: 1.1,
    },
    panelScroll: {
      flex: 1,
      minHeight: 0,
    },
    panelScrollContent: {
      paddingBottom: a.s(4),
    },
    rightPanelContent: {
      flex: 1,
      minHeight: 0,
    },
    playerScrollContent: {
      paddingBottom: a.s(4),
    },
    footerInside: {
      flexDirection: 'row',
      justifyContent: 'flex-end',
      alignItems: 'center',
      paddingTop: a.layoutPreset === 'phone' ? a.s(8) : a.s(10),
      marginTop: a.layoutPreset === 'phone' ? a.s(4) : a.s(6),
      borderTopWidth: 1,
      borderTopColor: 'rgba(255,255,255,0.06)',
    },
    footerButton: {
      minWidth: a.layoutPreset === 'phone' ? a.s(78) : a.s(86),
      height: a.layoutPreset === 'phone' ? a.s(36) : a.s(38),
      borderRadius: a.s(13),
      justifyContent: 'center',
      alignItems: 'center',
      paddingHorizontal: a.layoutPreset === 'phone' ? a.s(12) : a.s(14),
    },
    cancelButton: {
      backgroundColor: '#050505',
      borderWidth: 1.6,
      borderColor: colors.white,
      marginRight: a.layoutPreset === 'phone' ? a.s(8) : a.s(10),
    },
    startButton: {
      backgroundColor: '#D61F26',
      borderWidth: 1.6,
      borderColor: 'rgba(255,255,255,0.14)',
    },
    cancelText: {
      color: colors.white,
      fontSize: a.fs(a.layoutPreset === 'tv' ? 16 : 13, 0.96, 1.02),
      fontWeight: '700',
    },
    startText: {
      color: colors.white,
      fontSize: a.fs(a.layoutPreset === 'tv' ? 16 : 13, 0.96, 1.02),
      fontWeight: '800',
    },
    buttonPressed: {
      opacity: 0.86,
      transform: [{scale: 0.985}],
    },
  });
};

export default createStyles;
