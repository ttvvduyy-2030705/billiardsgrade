import {StyleSheet} from 'react-native';

import colors from 'configuration/colors';

import {AdaptiveLayout} from '../../useAdaptiveLayout';

const createStyles = (a: AdaptiveLayout) =>
  StyleSheet.create({
    container: {
      paddingBottom: a.s(4),
    },
    mainTitle: {
      color: '#FFFFFF',
      fontSize: a.fs(14, 0.96, 1.02),
      fontWeight: '800',
      marginBottom: a.layoutPreset === 'phone' ? a.s(8) : a.s(10),
      textShadowColor: 'rgba(0,0,0,0.35)',
      textShadowOffset: {width: 0, height: 0},
      textShadowRadius: 1,
    },
    section: {
      marginBottom: a.layoutPreset === 'phone' ? a.s(8) : a.s(10),
    },
    sectionTitle: {
      color: '#FFFFFF',
      fontSize: a.fs(a.layoutPreset === 'tv' ? 16 : 12.5, 0.96, 1.02),
      fontWeight: '800',
      marginBottom: a.s(6),
      textShadowColor: 'rgba(0,0,0,0.35)',
      textShadowOffset: {width: 0, height: 0},
      textShadowRadius: 1,
    },
    sectionDivider: {
      height: 1.1,
      backgroundColor: '#FF1F26',
      marginBottom: a.layoutPreset === 'phone' ? a.s(8) : a.s(10),
    },
    inlineRow: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: a.layoutPreset === 'phone' ? a.s(6) : a.s(8),
    },
    compactOptionRow: {
      marginBottom: a.layoutPreset === 'phone' ? a.s(5) : a.s(6),
    },
    inlineLabel: {
      width: a.layoutPreset === 'tv' ? a.s(68) : a.s(56),
      color: '#FFFFFF',
      fontSize: a.fs(a.layoutPreset === 'tv' ? 15 : 11.5, 0.96, 1.02),
      fontWeight: '700',
      marginRight: a.s(8),
      textShadowColor: 'rgba(0,0,0,0.35)',
      textShadowOffset: {width: 0, height: 0},
      textShadowRadius: 1,
    },
    inlineOptions: {
      flex: 1,
      minWidth: 0,
    },
    poolBlock: {
      marginBottom: a.s(6),
    },
    modeOnlyRow: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: a.s(6),
    },
    optionsWrap: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      alignItems: 'center',
    },
    optionButton: {
      minHeight: a.layoutPreset === 'phone' ? a.s(28) : a.s(30),
      paddingHorizontal: a.layoutPreset === 'tv' ? a.s(13) : a.s(11),
      paddingVertical: a.s(4),
      marginRight: a.s(6),
      marginBottom: a.layoutPreset === 'phone' ? a.s(5) : a.s(6),
      borderRadius: a.s(13),
      borderWidth: 1,
      borderColor: 'rgba(255,255,255,0.3)',
      backgroundColor: '#141414',
      justifyContent: 'center',
      alignItems: 'center',
    },
    optionButtonActive: {
      backgroundColor: '#E11D25',
      borderColor: '#E11D25',
    },
    optionButtonPressed: {
      opacity: 0.88,
    },
    optionText: {
      color: colors.white,
      fontSize: a.fs(a.layoutPreset === 'tv' ? 14 : 11.5, 0.96, 1.02),
      fontWeight: '600',
    },
    optionTextActive: {
      color: colors.white,
      fontWeight: '700',
    },
  });

export default createStyles;
