import React, {useCallback, useMemo} from 'react';
import {Pressable, Text, View} from 'react-native';

import i18n from 'i18n';
import {CUSHION, LIBRE, POOL} from 'constants/category';
import {
  GAME_COUNT_DOWN_TIME,
  GAME_EXTRA_TIME_BONUS,
  GAME_EXTRA_TIME_TURN,
  GAME_MODE,
  GAME_WARM_UP_TIME,
} from 'constants/game-settings';
import {BilliardCategory} from 'types/category';
import {
  GameCountDownTime,
  GameExtraTimeBonus,
  GameExtraTimeTurns,
  GameMode,
  GameSettingsMode,
  GameWarmUpTime,
} from 'types/settings';

import createStyles from './styles';
import useAdaptiveLayout from '../../useAdaptiveLayout';

interface Props {
  showTitle?: boolean;
  category?: BilliardCategory;
  gameMode?: GameMode;
  gameSettingsMode?: GameSettingsMode;
  extraTimeTurnsEnabled: boolean;
  countdownEnabled: boolean;
  warmUpEnabled: boolean;
  extraTimeBonusEnabled: boolean;
  onSelectCategory: (_selectedCategory: BilliardCategory) => void;
  onSelectGameMode: (_selectedGameMode: GameMode) => void;
  onSelectExtraTimeTurns: (_selectedExtraTimeTurns: GameExtraTimeTurns) => void;
  onSelectCountdown: (_selectedCountdownTime: GameCountDownTime) => void;
  onSelectWarmUp: (selectedWarmUpTime: GameWarmUpTime) => void;
  onSelectExtraTimeBonus: (_selectedExtraTimeBonus: GameExtraTimeBonus) => void;
}

const getLocale = () => {
  const maybeCurrentLocale =
    typeof (i18n as any)?.currentLocale === 'function'
      ? (i18n as any).currentLocale()
      : '';

  return String((i18n as any)?.locale ?? maybeCurrentLocale ?? '').toLowerCase();
};

const CategorySettings = ({
  showTitle = true,
  category,
  gameSettingsMode,
  extraTimeTurnsEnabled,
  countdownEnabled,
  warmUpEnabled,
  extraTimeBonusEnabled,
  onSelectCategory,
  onSelectGameMode,
  onSelectExtraTimeTurns,
  onSelectCountdown,
  onSelectWarmUp,
  onSelectExtraTimeBonus,
}: Props) => {
  const adaptive = useAdaptiveLayout();
  const styles = useMemo(() => createStyles(adaptive), [adaptive.styleKey]);
  const isEnglish = getLocale().startsWith('en');

  const translate = useCallback(
    (lookup: string, vi: string, en: string) => {
      const translated = i18n.t(lookup as never);
      if (translated && translated !== lookup) {
        return translated as string;
      }
      return isEnglish ? en : vi;
    },
    [isEnglish],
  );

  const categoryTitle = translate('category', 'Nội dung', 'Category');
  const caromTitle = translate('carom', 'Carom', 'Carom');
  const libreTitle = translate('libre', 'Libre', 'Libre');
  const poolTitle = translate('pool', 'Pool', 'Pool');
  const setupTitle = translate('setup', 'Thiết lập', 'Setup');
  const modeTitle = translate('mode', 'Chế độ', 'Mode');
  const extraTurnsTitle = translate('extraTimeTurns', 'Lượt thêm giờ', 'Extra turns');
  const countdownTitle = translate('countdownTime', 'Thời gian lượt', 'Shot clock');
  const warmUpTitle = translate('warmUpTime', 'Khởi động', 'Warm up');
  const extraTimeTitle = translate('extraTimeBonus', 'Thêm giờ', 'Extra time');

  const renderButtons = useCallback(
    (
      prefixKey: string,
      data: Record<string, number>,
      currentItem: number | string | undefined,
      onSelect: (value: any) => void,
      _useKey?: boolean,
    ) => {
      return (
        <View style={styles.optionsWrap}>
          {Object.keys(data).map((key, index) => {
            const item = data[key];
            const active = item === currentItem;
            return (
              <Pressable
                key={`${prefixKey}-${key}-${index}`}
                onPress={() => onSelect(item)}
                style={({pressed}) => [
                  styles.optionButton,
                  active && styles.optionButtonActive,
                  pressed && styles.optionButtonPressed,
                ]}>
                <Text
                  style={[
                    styles.optionText,
                    active && styles.optionTextActive,
                  ]}>
                  {key}
                </Text>
              </Pressable>
            );
          })}
        </View>
      );
    },
    [styles],
  );

  const renderInlineRow = useCallback(
    (
      label: string,
      data: Record<string, number>,
      currentItem: number | string | undefined,
      onSelect: (value: any) => void,
      useKey = false,
      rowStyle?: object,
    ) => {
      return (
        <View style={[styles.inlineRow, rowStyle]}>
          <Text style={styles.inlineLabel}>{label}</Text>
          <View style={styles.inlineOptions}>
            {renderButtons(label, data, currentItem, onSelect, useKey)}
          </View>
        </View>
      );
    },
    [renderButtons, styles.inlineLabel, styles.inlineOptions, styles.inlineRow],
  );

  return (
    <View style={styles.container}>
      {showTitle ? <Text style={styles.mainTitle}>{categoryTitle}</Text> : null}

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{categoryTitle}</Text>
        <View style={styles.sectionDivider} />

        {renderInlineRow(caromTitle, CUSHION, category, onSelectCategory)}
        {renderInlineRow(libreTitle, LIBRE, category, onSelectCategory)}

        <View style={styles.poolBlock}>
          <Text style={styles.inlineLabel}>{poolTitle}</Text>
          {renderButtons(poolTitle, POOL, category, onSelectCategory)}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{setupTitle}</Text>
        <View style={styles.sectionDivider} />

        <View style={styles.modeOnlyRow}>
          {renderButtons(
            modeTitle,
            GAME_MODE,
            gameSettingsMode?.mode,
            onSelectGameMode,
          )}
        </View>

        {extraTimeTurnsEnabled &&
          renderInlineRow(
            extraTurnsTitle,
            GAME_EXTRA_TIME_TURN,
            gameSettingsMode?.extraTimeTurns,
            onSelectExtraTimeTurns,
            true,
            styles.compactOptionRow,
          )}

        {countdownEnabled &&
          renderInlineRow(
            countdownTitle,
            GAME_COUNT_DOWN_TIME,
            gameSettingsMode?.countdownTime,
            onSelectCountdown,
            true,
            styles.compactOptionRow,
          )}

        {warmUpEnabled &&
          renderInlineRow(
            warmUpTitle,
            GAME_WARM_UP_TIME,
            gameSettingsMode?.warmUpTime,
            onSelectWarmUp,
            true,
            styles.compactOptionRow,
          )}

        {extraTimeBonusEnabled &&
          renderInlineRow(
            extraTimeTitle,
            GAME_EXTRA_TIME_BONUS,
            gameSettingsMode?.extraTimeBonus ?? 0,
            onSelectExtraTimeBonus,
            true,
            styles.compactOptionRow,
          )}
      </View>
    </View>
  );
};

export default CategorySettings;
