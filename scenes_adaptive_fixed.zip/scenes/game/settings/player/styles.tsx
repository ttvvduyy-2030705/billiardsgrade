import {StyleSheet} from 'react-native';

import colors from 'configuration/colors';

import {AdaptiveLayout} from '../../useAdaptiveLayout';

const createStyles = (a: AdaptiveLayout) =>
  StyleSheet.create({
    container: {
      paddingBottom: a.s(2),
    },
    mainTitle: {
      color: '#FFFFFF',
      fontSize: a.fs(14, 0.96, 1.02),
      fontWeight: '800',
      marginBottom: a.s(8),
      textShadowColor: 'rgba(0,0,0,0.35)',
      textShadowOffset: {width: 0, height: 0},
      textShadowRadius: 1,
    },
    topControls: {
      paddingTop: 0,
      marginBottom: a.s(4),
    },
    controlRow: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: a.s(6),
    },
    controlRowCompact: {
      marginBottom: a.s(5),
    },
    controlLabel: {
      width: a.layoutPreset === 'tv' ? a.s(68) : a.s(58),
      color: '#FFFFFF',
      fontSize: a.fs(a.layoutPreset === 'tv' ? 14 : 11.5, 0.96, 1.02),
      fontWeight: '700',
      marginRight: a.s(8),
      textShadowColor: 'rgba(0,0,0,0.35)',
      textShadowOffset: {width: 0, height: 0},
      textShadowRadius: 1,
    },
    controlOptionsRow: {
      flex: 1,
      flexDirection: 'row',
      flexWrap: 'wrap',
      alignItems: 'center',
    },
    selectorButton: {
      minWidth: a.layoutPreset === 'phone' ? a.s(30) : a.s(32),
      minHeight: a.layoutPreset === 'phone' ? a.s(28) : a.s(30),
      paddingHorizontal: a.layoutPreset === 'phone' ? a.s(8) : a.s(9),
      paddingVertical: a.s(4),
      marginRight: a.s(5),
      marginBottom: a.s(5),
      borderRadius: a.s(13),
      borderWidth: 1,
      borderColor: 'rgba(255,255,255,0.28)',
      backgroundColor: '#4A4A4A',
      alignItems: 'center',
      justifyContent: 'center',
    },
    selectorButtonActive: {
      backgroundColor: '#E11D25',
      borderColor: '#E11D25',
    },
    selectorButtonPressed: {
      opacity: 0.88,
    },
    selectorButtonText: {
      color: colors.white,
      fontSize: a.fs(a.layoutPreset === 'tv' ? 14 : 11.5, 0.96, 1.02),
      fontWeight: '600',
    },
    selectorButtonTextActive: {
      color: colors.white,
      fontWeight: '700',
    },
    playerList: {
      paddingTop: 0,
    },
    playerCard: {
      borderRadius: a.s(14),
      paddingHorizontal: a.layoutPreset === 'phone' ? a.s(6) : a.s(7),
      paddingVertical: a.layoutPreset === 'phone' ? a.s(6) : a.s(7),
      marginBottom: a.layoutPreset === 'phone' ? a.s(6) : a.s(8),
      borderWidth: 1,
      borderColor: 'rgba(255,255,255,0.08)',
      flexDirection: 'row',
      alignItems: 'stretch',
    },
    playerCardPool: {
      backgroundColor: '#4A4A4A',
      borderColor: 'rgba(255,48,48,0.38)',
    },
    playerCardRight: {
      flex: 1,
      justifyContent: 'center',
      marginLeft: a.layoutPreset === 'phone' ? a.s(6) : a.s(7),
    },
    playerCardTop: {
      flexDirection: 'row',
      alignItems: 'center',
      minHeight: a.layoutPreset === 'phone' ? a.s(30) : a.s(32),
    },
    avatar: {
      width: a.layoutPreset === 'phone' ? a.s(38) : a.s(40),
      minHeight: a.layoutPreset === 'phone' ? a.s(56) : a.s(58),
      borderRadius: a.s(10),
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#F4ECD1',
      overflow: 'hidden',
      alignSelf: 'stretch',
    },
    avatarPool: {
      backgroundColor: '#D8D8D8',
    },
    avatarDark: {
      backgroundColor: 'rgba(255,255,255,0.14)',
    },
    avatarText: {
      color: '#1A1A1A',
      fontSize: a.fs(30, 0.96, 1.02),
      lineHeight: a.fs(30, 0.96, 1.02),
      fontWeight: '700',
      textAlign: 'center',
      textAlignVertical: 'center',
      includeFontPadding: false,
    },
    avatarTextLight: {
      color: colors.white,
    },
    nameInput: {
      flex: 1,
      height: a.layoutPreset === 'phone' ? a.s(30) : a.s(32),
      borderRadius: a.s(9),
      backgroundColor: '#F5F0DA',
      paddingHorizontal: a.layoutPreset === 'phone' ? a.s(8) : a.s(9),
      paddingVertical: 0,
      color: '#1A1A1A',
      fontSize: a.fs(a.layoutPreset === 'tv' ? 14 : 12.5, 0.96, 1.02),
      lineHeight: a.fs(a.layoutPreset === 'tv' ? 18 : 14, 0.96, 1.02),
      fontWeight: '500',
      textAlignVertical: 'center',
    },
    nameInputPool: {
      backgroundColor: '#D9D9D9',
      color: '#1B1B1B',
    },
    scoreRow: {
      flexDirection: 'row',
      alignItems: 'center',
      borderRadius: a.s(9),
      backgroundColor: '#F5F0DA',
      overflow: 'hidden',
      marginTop: a.s(6),
    },
    scoreRowPool: {
      backgroundColor: '#6A6A6A',
    },
    scoreItem: {
      flex: 1,
      minHeight: a.layoutPreset === 'phone' ? a.s(22) : a.s(24),
      alignItems: 'center',
      justifyContent: 'center',
      borderRightWidth: 1,
      borderRightColor: 'rgba(0,0,0,0.12)',
    },
    scoreItemPool: {
      borderRightColor: 'rgba(255,255,255,0.18)',
    },
    scoreItemCenter: {
      backgroundColor: '#EEE6C5',
    },
    scoreItemCenterPool: {
      backgroundColor: '#E11D25',
    },
    scoreText: {
      color: '#202020',
      fontSize: a.fs(a.layoutPreset === 'tv' ? 13 : 10.5, 0.96, 1.02),
      fontWeight: '500',
    },
    scoreTextPool: {
      color: colors.white,
    },
    scoreTextCenter: {
      fontWeight: '700',
    },

    countryModalOverlay: {
      flex: 1,
      backgroundColor: 'rgba(0,0,0,0.45)',
      justifyContent: 'center',
      alignItems: 'center',
      paddingHorizontal: a.s(20),
    },
    countryModalCard: {
      width: '100%',
      maxWidth: 420,
      maxHeight: '72%',
      backgroundColor: '#1F1F1F',
      borderRadius: a.s(14),
      borderWidth: 1,
      borderColor: 'rgba(255,0,0,0.28)',
      padding: a.s(14),
    },
    countryModalTitle: {
      color: '#FFFFFF',
      fontSize: a.fs(16, 0.96, 1.02),
      fontWeight: '700',
      marginBottom: a.s(10),
    },
    countrySearchInput: {
      height: a.s(42),
      borderRadius: a.s(10),
      backgroundColor: '#2B2B2B',
      borderWidth: 1,
      borderColor: 'rgba(255,255,255,0.08)',
      color: '#FFFFFF',
      paddingHorizontal: a.s(12),
      marginBottom: a.s(10),
    },
    countryList: {
      flexGrow: 0,
    },
    countryItem: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: a.s(10),
      paddingHorizontal: a.s(8),
      borderRadius: a.s(10),
    },
    countryItemPressed: {
      backgroundColor: 'rgba(255,255,255,0.06)',
    },
    countryFlag: {
      width: a.s(28),
      fontSize: a.fs(20, 0.96, 1.02),
      marginRight: a.s(10),
      textAlign: 'center',
    },
    countryName: {
      color: '#FFFFFF',
      fontSize: a.fs(15, 0.96, 1.02),
      flex: 1,
    },
    countryEmptyText: {
      color: '#B8B8B8',
      fontSize: a.fs(14, 0.96, 1.02),
      textAlign: 'center',
      paddingVertical: a.s(20),
    },
  });

export default createStyles;
