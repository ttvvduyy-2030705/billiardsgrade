import {useMemo} from 'react';
import {PixelRatio, useWindowDimensions} from 'react-native';

export type WidthClass = 'compact' | 'medium' | 'expanded';
export type LayoutPreset = 'phone' | 'tablet' | 'wideTablet' | 'tv';

export type AdaptiveLayout = {
  width: number;
  height: number;
  shortSide: number;
  longSide: number;
  aspectRatio: number;
  isLandscape: boolean;
  isShortLandscape: boolean;
  isVeryShortLandscape: boolean;
  widthClass: WidthClass;
  layoutPreset: LayoutPreset;
  scale: number;
  sizeScale: number;
  textScale: number;
  styleKey: string;
  s: (value: number) => number;
  fs: (value: number, minFactor?: number, maxFactor?: number) => number;
};

const clamp = (value: number, min: number, max: number) =>
  Math.max(min, Math.min(max, value));

const round = (value: number) => PixelRatio.roundToNearestPixel(value);

export const useAdaptiveLayout = (): AdaptiveLayout => {
  const {width, height, fontScale} = useWindowDimensions();

  return useMemo(() => {
    const safeWidth = Number.isFinite(width) && width > 0 ? width : 1;
    const safeHeight = Number.isFinite(height) && height > 0 ? height : 1;
    const shortSide = Math.min(safeWidth, safeHeight);
    const longSide = Math.max(safeWidth, safeHeight);
    const aspectRatio = longSide / Math.max(shortSide, 1);
    const isLandscape = safeWidth >= safeHeight;

    const widthClass: WidthClass =
      safeWidth < 600 ? 'compact' : safeWidth < 900 ? 'medium' : 'expanded';

    const isShortLandscape =
      isLandscape &&
      (
        safeHeight <= 760 ||
        (safeHeight <= 820 && aspectRatio >= 1.82) ||
        (safeHeight <= 900 && aspectRatio >= 2.0)
      );
    const isVeryShortLandscape =
      isLandscape &&
      (
        safeHeight <= 680 ||
        (safeHeight <= 760 && aspectRatio >= 1.82) ||
        (safeHeight <= 840 && aspectRatio >= 2.08)
      );

    let layoutPreset: LayoutPreset = 'phone';

    if (widthClass === 'expanded' && (safeWidth >= 1366 || shortSide >= 900)) {
      layoutPreset = 'tv';
    } else if (
      isLandscape &&
      ((widthClass === 'expanded' && aspectRatio >= 1.45) ||
        (widthClass === 'medium' && aspectRatio >= 1.5))
    ) {
      layoutPreset = 'wideTablet';
    } else if (widthClass === 'medium' || widthClass === 'expanded') {
      layoutPreset = 'tablet';
    }

    const widthBase =
      layoutPreset === 'tv'
        ? 1366
        : layoutPreset === 'wideTablet'
          ? 1180
          : layoutPreset === 'tablet'
            ? 1024
            : 420;

    const heightBase =
      layoutPreset === 'tv'
        ? 768
        : layoutPreset === 'wideTablet'
          ? 720
          : layoutPreset === 'tablet'
            ? 760
            : 800;

    const widthFactor = safeWidth / widthBase;
    const heightFactor = safeHeight / heightBase;
    const aspectBias = isLandscape
      ? clamp((aspectRatio - 1.35) * 0.08, -0.03, 0.05)
      : clamp((1.7 - aspectRatio) * 0.03, -0.02, 0.04);

    const targetBase = widthFactor * 0.68 + heightFactor * 0.32 + aspectBias;

    const compactPenalty =
      isVeryShortLandscape ? 0.17 : isShortLandscape ? 0.11 : 0;

    const scale = clamp(
      targetBase - compactPenalty,
      layoutPreset === 'phone' ? 0.74 : 0.76,
      layoutPreset === 'tv' ? 1.18 : 1.06,
    );

    const textScale = clamp(
      scale / Math.min(fontScale || 1, 1.15),
      layoutPreset === 'phone' ? 0.72 : 0.74,
      layoutPreset === 'tv' ? 1.1 : 1.0,
    );

    const s = (value: number) => {
      const next = round(value * scale);
      return Number.isFinite(next) ? next : value;
    };

    const fs = (value: number, minFactor = 0.84, maxFactor = 1.08) => {
      const next = round(clamp(value * textScale, value * minFactor, value * maxFactor));
      return Number.isFinite(next) ? next : value;
    };

    return {
      width: safeWidth,
      height: safeHeight,
      shortSide,
      longSide,
      aspectRatio,
      isLandscape,
      isShortLandscape,
      isVeryShortLandscape,
      widthClass,
      layoutPreset,
      scale,
      sizeScale: scale,
      textScale,
      styleKey: `${Math.round(safeWidth)}x${Math.round(safeHeight)}-${layoutPreset}-${widthClass}`,
      s,
      fs,
    };
  }, [fontScale, height, width]);
};

export default useAdaptiveLayout;
