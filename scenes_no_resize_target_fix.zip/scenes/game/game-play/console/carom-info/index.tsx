import React, {memo, useCallback} from 'react';
import {Image as RNImage, TextStyle, useWindowDimensions} from 'react-native';
import View from 'components/View';
import Text from 'components/Text';
import Image from 'components/Image';
import Countdown from 'components/Countdown';
import colors from 'configuration/colors';
import {Player} from 'types/player';

import {dims} from 'configuration';
import images from 'assets';
import CaromInfoViewModel, {Props} from './CaromInfoViewModel';
import styles from './styles';
import {getCountryFlagImageUri} from '../../../settings/player/countries';


const isRemoteUri = (value?: string) => /^https?:\/\//i.test(String(value || '').trim());

const getPlayerFlagImageUri = (player?: {countryCode?: string; flag?: string}) => {
  const fromCode = getCountryFlagImageUri(player?.countryCode, 80);
  if (fromCode) {
    return fromCode;
  }

  const rawFlag = String(player?.flag || '').trim();
  return isRemoteUri(rawFlag) ? rawFlag : '';
};

const getPlayerFlagText = (player?: {flag?: string}) => {
  const rawFlag = String(player?.flag || '').trim();
  return isRemoteUri(rawFlag) ? '' : rawFlag;
};

const CaromInfo = (props: Props) => {
  const viewModel = CaromInfoViewModel(props);
  const {width, height} = useWindowDimensions();
  const shortestSide = Math.min(width, height);
  const longestSide = Math.max(width, height);
  const isLandscape = width > height;
  const isLargeDisplay = longestSide >= 1800 || shortestSide >= 1100;
  const isSmallLandscapeDisplay = isLandscape && !isLargeDisplay && width <= 1400 && height <= 900;
  const isCondensed = isLandscape && !isLargeDisplay && (height <= 980 || shortestSide <= 1000);
  const isUltraCondensed = isLandscape && !isLargeDisplay && (height <= 760 || shortestSide <= 860);
  const infoScale = isSmallLandscapeDisplay ? 0.74 : isUltraCondensed ? 0.8 : isCondensed ? 0.88 : 1;
  const isLibre = props.gameSettings?.category === 'libre';

  const getTotalPointFont = useCallback(
    (point: number) => {
      const value = Number(point || 0);

      if (!isLibre) {
        return {
          fontSize: Math.round(40 * infoScale),
          lineHeight: Math.round(46 * infoScale),
        };
      }

      if (value >= 1000) {
        return {
          fontSize: Math.round((isSmallLandscapeDisplay ? 18 : 22) * infoScale),
          lineHeight: Math.round((isSmallLandscapeDisplay ? 22 : 26) * infoScale),
        };
      }

      if (value >= 100) {
        return {
          fontSize: Math.round((isSmallLandscapeDisplay ? 24 : 30) * infoScale),
          lineHeight: Math.round((isSmallLandscapeDisplay ? 28 : 34) * infoScale),
        };
      }

      return {
        fontSize: Math.round(40 * infoScale),
        lineHeight: Math.round(46 * infoScale),
      };
    },
    [infoScale, isLibre, isSmallLandscapeDisplay],
  );

  const renderPlayer = useCallback(
    (player: Player, index: number, totalPointStyle: TextStyle) => {
      const totalPointValue = Number(player.totalPoint || 0);
      const totalPointFont = getTotalPointFont(totalPointValue);

      const playerFlag = getPlayerFlagText(player as any);
      const playerFlagImage = getPlayerFlagImageUri(player as any);

      return (
        <View
          style={{backgroundColor: player.color}}
          direction={'row'}
          alignItems={'center'}>
          <View direction={'row'} alignItems={'center'} paddingLeft={isSmallLandscapeDisplay ? '6' : '10'}>
            {playerFlagImage || playerFlag ? (
              <View style={[styles.flagBadge, isSmallLandscapeDisplay ? {width: 28, height: 20, marginRight: 6} : undefined]}>
                {playerFlagImage ? (
                  <RNImage
                    source={{uri: playerFlagImage}}
                    resizeMode="cover"
                    fadeDuration={0}
                    style={{width: '100%', height: '100%', backgroundColor: '#FFFFFF'}}
                  />
                ) : (
                  <Text style={[styles.flagText, isSmallLandscapeDisplay ? {fontSize: 12, lineHeight: 14} : undefined]}>{playerFlag}</Text>
                )}
              </View>
            ) : null}

            <View flex={'1'} style={playerFlag ? [styles.nameWithFlag, isSmallLandscapeDisplay ? {marginRight: 2} : undefined] : undefined}>
              <Text fontSize={isSmallLandscapeDisplay ? 18 : 22} fontWeight={'900'} numberOfLines={1} style={isSmallLandscapeDisplay ? {letterSpacing: -0.2} : undefined}>
                {player.name.toUpperCase()}
              </Text>
            </View>

            {props.currentPlayerIndex === index ? (
              <Image source={images.game.turn} style={[styles.turnImage, isSmallLandscapeDisplay ? {width: 30, height: 30, marginLeft: 6, marginRight: -2} : undefined]} />
            ) : (
              <View style={[styles.empty, isSmallLandscapeDisplay ? {width: 30, height: 30, marginLeft: 6} : undefined]} />
            )}

            <View direction={'row'} alignItems={'end'}>
              <View style={[styles.totalPointWrapper, isSmallLandscapeDisplay ? {minWidth: 58} : undefined]} paddingHorizontal={isSmallLandscapeDisplay ? '6' : '10'}>
                <Text
                  style={totalPointStyle}
                  fontSize={totalPointFont.fontSize}
                  lineHeight={totalPointFont.lineHeight}
                  fontWeight={'bold'}
                  color={colors.white}
                  numberOfLines={1}>
                  {totalPointValue}
                </Text>
              </View>

              <View style={[styles.currentTotalPoint, isSmallLandscapeDisplay ? {minWidth: 34, marginBottom: 0} : undefined]} paddingHorizontal={isSmallLandscapeDisplay ? '6' : '10'}>
                <Text
                  style={styles.currentPointText}
                  fontSize={32}
                  lineHeight={38}
                  fontWeight={'bold'}>
                  {player.proMode?.currentPoint || 0}
                </Text>
              </View>
            </View>
          </View>
        </View>
      );
    },
    [props.currentPlayerIndex, getTotalPointFont],
  );

  if (!props.gameSettings.mode?.countdownTime) {
    return <View />;
  }

  return (
    <View style={styles.container} direction={'row'} marginTop={'10'}>
      <View flex={'1'}>
        <View
          collapsable={false}
          style={styles.countdownContainer}
          direction={'row'}>
          <View>
            <View
              flex={'1'}
              justify={'center'}
              style={styles.totalTurnWrapper}
              paddingHorizontal={isSmallLandscapeDisplay ? '12' : '20'}>
              <Text color={colors.white} fontSize={isSmallLandscapeDisplay ? 42 : 56} lineHeight={isSmallLandscapeDisplay ? 52 : 70}>
                {Math.max(1, Number(props.totalTurns || 1))}
              </Text>
            </View>
          </View>

          <View flex={'1'}>
            {renderPlayer(viewModel.player0, 0, styles.totalPointText0)}
            {renderPlayer(viewModel.player1, 1, styles.totalPointText1)}
          </View>
        </View>

        <View
          collapsable={false}
          style={styles.countdownContainer}
          direction={'row'}
          alignItems={'center'}>
          <View
            style={styles.countdownWrapper}
            paddingHorizontal={'20'}
            marginLeft={'5'}>
            <Text fontSize={isSmallLandscapeDisplay ? 16 : 20} color={colors.white}>
              {props.countdownTime}
            </Text>
          </View>

          <View flex={'1'} direction={'row'}>
            <Countdown
              originalCountdownTime={props.gameSettings.mode?.countdownTime}
              currentCountdownTime={props.countdownTime}
              countdownWidth={dims.screenWidth * 0.28}
              heightItem={isSmallLandscapeDisplay ? 18 : 27}
              marginHorizontal={isSmallLandscapeDisplay ? 1 : 2}
              direction="right-to-left"
              colorMode="threshold"
              yellowThreshold={10}
              redThreshold={5}
            />
          </View>
        </View>
      </View>
    </View>
  );
};

export default memo(CaromInfo);