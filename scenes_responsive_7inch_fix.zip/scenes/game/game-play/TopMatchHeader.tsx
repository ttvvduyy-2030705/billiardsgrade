import React, {memo} from 'react';
import {StyleSheet, Text as RNText, useWindowDimensions} from 'react-native';

import View from 'components/View';
import Button from 'components/Button';
import Image from 'components/Image';
import Switch from 'components/Switch';

import images from 'assets';
import colors from 'configuration/colors';
import i18n from 'i18n';
import {
  isPoolGame,
  isPool9Game,
  isPool10Game,
  isPool15Game,
  isPool15OnlyGame,
} from 'utils/game';

interface Props {
  title: string;
  soundEnabled: boolean;
  onToggleSound: () => void;
  remoteEnabled?: boolean;
  onToggleRemote?: (value: boolean) => void;
  proModeEnabled?: boolean;
  onToggleProMode?: (value: boolean) => void;
  gameSettings?: any;
}

const localeText = (vi: string, en: string) => {
  const locale = String(
    (i18n as any)?.locale || (i18n as any)?.language || '',
  ).toLowerCase();
  return locale.startsWith('en') ? en : vi;
};

const TopMatchHeader = ({
  title,
  soundEnabled,
  onToggleSound,
  remoteEnabled = false,
  onToggleRemote,
  proModeEnabled = false,
  onToggleProMode,
  gameSettings,
}: Props) => {
  const isAnyPoolMode =
    isPoolGame(gameSettings?.category) ||
    isPool9Game(gameSettings?.category) ||
    isPool10Game(gameSettings?.category) ||
    isPool15Game(gameSettings?.category) ||
    isPool15OnlyGame(gameSettings?.category);

  const {width, height} = useWindowDimensions();
  const shortestSide = Math.min(width, height);
  const isLandscape = width > height;
  const isShortLandscapeDisplay = isLandscape && height <= 820;
  const isVeryShortLandscapeDisplay = isLandscape && height <= 720;
  const useCompactHeader = shortestSide < 650 || isShortLandscapeDisplay;

  return (
    <View
      style={[
        styles.header,
        useCompactHeader ? styles.headerCompact : undefined,
        isVeryShortLandscapeDisplay ? styles.headerVeryCompact : undefined,
      ]}>
      <View
        style={[
          styles.logoSlot,
          useCompactHeader ? styles.logoSlotCompact : undefined,
          isVeryShortLandscapeDisplay ? styles.logoSlotVeryCompact : undefined,
        ]}>
        <Image
          source={images.logoSmall || images.logo}
          resizeMode="contain"
          style={[
            styles.logo,
            useCompactHeader ? styles.logoCompact : undefined,
            isVeryShortLandscapeDisplay ? styles.logoVeryCompact : undefined,
          ]}
        />
      </View>

      <View style={[styles.titleSlot, useCompactHeader ? styles.titleSlotCompact : undefined]}>
        <RNText
          numberOfLines={1}
          adjustsFontSizeToFit
          minimumFontScale={0.72}
          style={[
            styles.titleText,
            useCompactHeader ? styles.titleTextCompact : undefined,
            isVeryShortLandscapeDisplay ? styles.titleTextVeryCompact : undefined,
          ]}>
          {title}
        </RNText>
      </View>

      <View
        style={[
          styles.rightSlot,
          useCompactHeader ? styles.rightSlotCompact : undefined,
          isVeryShortLandscapeDisplay ? styles.rightSlotVeryCompact : undefined,
        ]}>
        <View
          style={[
            styles.switchGroup,
            useCompactHeader ? styles.switchGroupCompact : undefined,
            isVeryShortLandscapeDisplay ? styles.switchGroupVeryCompact : undefined,
          ]}>
          {!isAnyPoolMode ? (
            <View style={[styles.switchRow, useCompactHeader ? styles.switchRowCompact : undefined]}>
              <RNText
                numberOfLines={1}
                style={[
                  styles.switchLabel,
                  useCompactHeader ? styles.switchLabelCompact : undefined,
                ]}>
                Pro Mode
              </RNText>
              <Switch
                defaultValue={proModeEnabled}
                onChange={value => onToggleProMode?.(value)}
              />
            </View>
          ) : null}

          <View style={[styles.switchRow, useCompactHeader ? styles.switchRowCompact : undefined]}>
            <RNText
              numberOfLines={1}
              style={[
                styles.switchLabel,
                useCompactHeader ? styles.switchLabelCompact : undefined,
              ]}>
              {localeText('Điều khiển', 'Remote')}
            </RNText>
            <Switch
              defaultValue={remoteEnabled}
              onChange={value => onToggleRemote?.(value)}
            />
          </View>
        </View>

        <Button
          onPress={onToggleSound}
          style={[
            styles.soundButton,
            useCompactHeader ? styles.soundButtonCompact : undefined,
            isVeryShortLandscapeDisplay ? styles.soundButtonVeryCompact : undefined,
          ]}>
          <Image
            source={soundEnabled ? images.game.soundOn : images.game.soundOff}
            style={[
              styles.soundIcon,
              useCompactHeader ? styles.soundIconCompact : undefined,
              isVeryShortLandscapeDisplay ? styles.soundIconVeryCompact : undefined,
              {tintColor: soundEnabled ? '#FFFFFF' : '#7A7A7A'},
            ]}
            resizeMode={'contain'}
          />
        </Button>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  header: {
    minHeight: 74,
    borderRadius: 24,
    borderWidth: 1.2,
    borderColor: 'rgba(255, 32, 32, 0.55)',
    backgroundColor: '#0A0B0E',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 10,
    shadowColor: '#ff1f1f',
    shadowOpacity: 0.18,
    shadowRadius: 14,
    shadowOffset: {width: 0, height: 0},
    elevation: 10,
  },
  headerCompact: {
    minHeight: 60,
    borderRadius: 18,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  headerVeryCompact: {
    minHeight: 54,
    borderRadius: 16,
    paddingHorizontal: 8,
    paddingVertical: 5,
  },

  logoSlot: {
    width: 170,
    alignItems: 'flex-start',
    justifyContent: 'center',
  },
  logoSlotCompact: {
    width: 118,
  },
  logoSlotVeryCompact: {
    width: 96,
  },

  logo: {
    width: 98,
    height: 40,
  },
  logoCompact: {
    width: 78,
    height: 32,
  },
  logoVeryCompact: {
    width: 64,
    height: 26,
  },

  titleSlot: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 0,
  },
  titleSlotCompact: {
    paddingHorizontal: 4,
  },

  titleText: {
    color: '#FFFFFF',
    fontSize: 35,
    lineHeight: 40,
    fontWeight: '900',
    textAlign: 'center',
    includeFontPadding: false,
    width: '100%',
    transform: [{translateX: 30}],
  },
  titleTextCompact: {
    fontSize: 24,
    lineHeight: 28,
    transform: [{translateX: 0}],
  },
  titleTextVeryCompact: {
    fontSize: 20,
    lineHeight: 24,
  },

  rightSlot: {
    width: 224,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  rightSlotCompact: {
    width: 152,
  },
  rightSlotVeryCompact: {
    width: 128,
  },

  switchGroup: {
    width: 172,
  },
  switchGroupCompact: {
    width: 118,
  },
  switchGroupVeryCompact: {
    width: 98,
  },

  switchRow: {
    minHeight: 30,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  switchRowCompact: {
    minHeight: 24,
  },

  switchLabel: {
    color: colors.white,
    fontSize: 14,
    fontWeight: '600',
  },
  switchLabelCompact: {
    fontSize: 11,
  },

  soundButton: {
    width: 36,
    height: 36,
    marginLeft: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  soundButtonCompact: {
    width: 28,
    height: 28,
    marginLeft: 6,
  },
  soundButtonVeryCompact: {
    width: 24,
    height: 24,
    marginLeft: 4,
  },

  soundIcon: {
    width: 22,
    height: 22,
    tintColor: '#FFFFFF',
  },
  soundIconCompact: {
    width: 16,
    height: 16,
  },
  soundIconVeryCompact: {
    width: 14,
    height: 14,
  },
});

export default memo(TopMatchHeader);
