import React, {memo, useMemo} from 'react';

import Button from 'components/Button';
import Text from 'components/Text';
import View from 'components/View';
import useAdaptiveLayout from '../useAdaptiveLayout';

interface Props {
  originalCountdownTime?: number;
  currentCountdownTime: number;
  onPress?: () => void;
}

const SEGMENTS = 34;

const PoolShotClock = ({
  originalCountdownTime = 40,
  currentCountdownTime,
  onPress,
}: Props) => {
  const adaptive = useAdaptiveLayout();
  const isLargeDisplay = adaptive.layoutPreset === 'tv';
  const isUltraShortLandscape = adaptive.isUltraShortLandscape;
  const isShortLandscape = adaptive.isShortLandscape;

  const segmentHeight = isLargeDisplay
    ? 92
    : isUltraShortLandscape
      ? 18
      : isShortLandscape
        ? 22
        : 28;
  const segmentWrapMinHeight = isLargeDisplay
    ? 98
    : isUltraShortLandscape
      ? 20
      : isShortLandscape
        ? 24
        : 32;
  const secondsFontSize = isLargeDisplay
    ? 58
    : isUltraShortLandscape
      ? 16
      : isShortLandscape
        ? 18
        : 20;
  const secondsMarginLeft = isLargeDisplay ? '16' : isUltraShortLandscape ? '6' : '10';

  const safeOriginal = Math.max(1, originalCountdownTime || 40);
  const safeCurrent = Math.max(0, currentCountdownTime);
  const progressMax = Math.max(safeOriginal, safeCurrent);

  const activeColor =
    safeCurrent <= 5 ? '#FF2D22' : safeCurrent <= 10 ? '#FFBE2F' : '#20E247';

  const litCount = useMemo(() => {
    return Math.max(0, Math.ceil((safeCurrent / progressMax) * SEGMENTS));
  }, [safeCurrent, progressMax]);

  return (
    <Button
      onPress={onPress}
      style={{
        width: '100%',
        paddingTop: 0,
        paddingBottom: 0,
      }}>
      <View
        style={{width: '100%'}}
        direction={'row'}
        alignItems={'center'}
        justify={'between'}>
        <View
          flex={'1'}
          direction={'row'}
          justify={'between'}
          alignItems={'center'}
          style={{minHeight: segmentWrapMinHeight}}>
          {Array.from({length: SEGMENTS}, (_, index) => {
            const isLit = index < litCount;
            return (
              <View
                key={`clock-segment-${index}`}
                style={{
                  flex: 1,
                  height: segmentHeight,
                  marginHorizontal: isUltraShortLandscape ? 1 : 2,
                  borderRadius: isLargeDisplay ? 8 : isUltraShortLandscape ? 3 : 4,
                  backgroundColor: isLit ? activeColor : '#2A2B31',
                  opacity: isLit ? 1 : 0.98,
                }}
              />
            );
          })}
        </View>

        <Text
          color={activeColor}
          fontSize={secondsFontSize}
          fontWeight={'bold'}
          marginLeft={secondsMarginLeft}>
          {`${safeCurrent}s`}
        </Text>
      </View>
    </Button>
  );
};

export default memo(PoolShotClock);
