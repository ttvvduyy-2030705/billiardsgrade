import {useMemo} from 'react';
import {PixelRatio, useWindowDimensions} from 'react-native';

export type WidthClass = 'compact' | 'medium' | 'expanded';
export type LayoutPreset = 'phone' | 'tablet' | 'wideTablet' | 'tv';

export type AdaptiveLayout = {
  width: number;
  height: number;
  shortSide: number;
  longSide: number;
  aspectRatio: number;
  isLandscape: boolean;
  isShortLandscape: boolean;
  isVeryShortLandscape: boolean;
  isUltraShortLandscape: boolean;
  widthClass: WidthClass;
  layoutPreset: LayoutPreset;
  scale: number;
  sizeScale: number;
  textScale: number;
  styleKey: string;
  s: (value: number) => number;
  fs: (value: number, minFactor?: number, maxFactor?: number) => number;
};

const clamp = (value: number, min: number, max: number) =>
  Math.max(min, Math.min(max, value));

const round = (value: number) => PixelRatio.roundToNearestPixel(value);

export const useAdaptiveLayout = (): AdaptiveLayout => {
  const {width, height, fontScale} = useWindowDimensions();

  return useMemo(() => {
    const safeWidth = Number.isFinite(width) && width > 0 ? width : 1;
    const safeHeight = Number.isFinite(height) && height > 0 ? height : 1;
    const shortSide = Math.min(safeWidth, safeHeight);
    const longSide = Math.max(safeWidth, safeHeight);
    const aspectRatio = longSide / Math.max(shortSide, 1);
    const isLandscape = safeWidth >= safeHeight;

    const widthClass: WidthClass =
      safeWidth < 600 ? 'compact' : safeWidth < 900 ? 'medium' : 'expanded';

    const isShortLandscape = isLandscape && safeHeight <= 760;
    const isVeryShortLandscape = isLandscape && safeHeight <= 680;
    const isUltraShortLandscape = isLandscape && safeHeight <= 620;

    let layoutPreset: LayoutPreset = 'phone';

    if (widthClass === 'expanded' && (safeWidth >= 1366 || shortSide >= 900)) {
      layoutPreset = 'tv';
    } else if (
      isLandscape &&
      ((widthClass === 'expanded' && aspectRatio >= 1.45) ||
        (widthClass === 'medium' && aspectRatio >= 1.5))
    ) {
      layoutPreset = 'wideTablet';
    } else if (widthClass === 'medium' || widthClass === 'expanded') {
      layoutPreset = 'tablet';
    }

    const widthBase =
      layoutPreset === 'tv'
        ? 1366
        : layoutPreset === 'wideTablet'
          ? 1180
          : layoutPreset === 'tablet'
            ? 1024
            : 420;

    const heightBase =
      layoutPreset === 'tv'
        ? 768
        : layoutPreset === 'wideTablet'
          ? 720
          : layoutPreset === 'tablet'
            ? 760
            : 800;

    const widthFactor = safeWidth / widthBase;
    const heightFactor = safeHeight / heightBase;

    const landscapeAspectBias = clamp((1.5 - aspectRatio) * 0.08, -0.14, 0.02);
    const portraitAspectBias = clamp((1.75 - aspectRatio) * 0.03, -0.02, 0.04);
    const aspectBias = isLandscape ? landscapeAspectBias : portraitAspectBias;

    const targetBase = isLandscape
      ? heightFactor * 0.8 + widthFactor * 0.2 + aspectBias
      : widthFactor * 0.58 + heightFactor * 0.42 + aspectBias;

    const compactPenalty = isUltraShortLandscape
      ? 0.2
      : isVeryShortLandscape
        ? 0.14
        : isShortLandscape
          ? 0.08
          : 0;

    const minScale = isLandscape
      ? isUltraShortLandscape
        ? 0.54
        : isVeryShortLandscape
          ? 0.58
          : layoutPreset === 'phone'
            ? 0.72
            : 0.68
      : layoutPreset === 'phone'
        ? 0.78
        : 0.8;

    const maxScale = layoutPreset === 'tv' ? 1.2 : 1.06;

    const scale = clamp(targetBase - compactPenalty, minScale, maxScale);

    const textScale = clamp(
      scale / Math.min(fontScale || 1, 1.15),
      isLandscape
        ? isUltraShortLandscape
          ? 0.56
          : isVeryShortLandscape
            ? 0.6
            : 0.68
        : layoutPreset === 'phone'
          ? 0.76
          : 0.78,
      layoutPreset === 'tv' ? 1.12 : 1.02,
    );

    const s = (value: number) => {
      const next = round(value * scale);
      return Number.isFinite(next) ? next : value;
    };

    const fs = (value: number, minFactor = 0.84, maxFactor = 1.06) => {
      const next = round(clamp(value * textScale, value * minFactor, value * maxFactor));
      return Number.isFinite(next) ? next : value;
    };

    return {
      width: safeWidth,
      height: safeHeight,
      shortSide,
      longSide,
      aspectRatio,
      isLandscape,
      isShortLandscape,
      isVeryShortLandscape,
      isUltraShortLandscape,
      widthClass,
      layoutPreset,
      scale,
      sizeScale: scale,
      textScale,
      styleKey: `${Math.round(safeWidth)}x${Math.round(safeHeight)}-${layoutPreset}-${widthClass}-${isUltraShortLandscape ? 'ultra' : isVeryShortLandscape ? 'veryshort' : isShortLandscape ? 'short' : 'normal'}`,
      s,
      fs,
    };
  }, [fontScale, height, width]);
};

export default useAdaptiveLayout;
