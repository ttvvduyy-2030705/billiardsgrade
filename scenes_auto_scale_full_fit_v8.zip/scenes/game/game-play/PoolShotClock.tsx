import React, {memo, useMemo} from 'react';

import Button from 'components/Button';
import Text from 'components/Text';
import View from 'components/View';

import useAdaptiveLayout from '../useAdaptiveLayout';

interface Props {
  originalCountdownTime?: number;
  currentCountdownTime: number;
  onPress?: () => void;
}

const SEGMENTS = 34;

const PoolShotClock = ({
  originalCountdownTime = 40,
  currentCountdownTime,
  onPress,
}: Props) => {
  const adaptive = useAdaptiveLayout();
  const isLargeDisplay = adaptive.layoutPreset === 'tv';

  const clockScale = useMemo(() => {
    const base = adaptive.textScale;
    const shortPenalty = adaptive.isVeryShortLandscape
      ? 0.12
      : adaptive.isShortLandscape
        ? 0.06
        : 0;
    return Math.max(
      adaptive.isVeryShortLandscape ? 0.52 : adaptive.isShortLandscape ? 0.62 : 0.72,
      Math.min(isLargeDisplay ? 1.08 : 1, base - shortPenalty),
    );
  }, [adaptive.isShortLandscape, adaptive.isVeryShortLandscape, adaptive.textScale, isLargeDisplay]);

  const segmentHeight = Math.round((isLargeDisplay ? 92 : 28) * clockScale);
  const segmentWrapMinHeight = Math.round((isLargeDisplay ? 98 : 32) * clockScale);
  const secondsFontSize = Math.round((isLargeDisplay ? 58 : 20) * clockScale);
  const secondsMarginLeft = String(Math.round((isLargeDisplay ? 16 : 10) * clockScale));
  const segmentRadius = Math.round((isLargeDisplay ? 8 : 4) * clockScale);
  const segmentMargin = Math.max(1, Math.round(2 * clockScale));

  const safeOriginal = Math.max(1, originalCountdownTime || 40);
  const safeCurrent = Math.max(0, currentCountdownTime);
  const progressMax = Math.max(safeOriginal, safeCurrent);

  const activeColor =
    safeCurrent <= 5 ? '#FF2D22' : safeCurrent <= 10 ? '#FFBE2F' : '#20E247';

  const litCount = useMemo(() => {
    return Math.max(0, Math.ceil((safeCurrent / progressMax) * SEGMENTS));
  }, [safeCurrent, progressMax]);

  return (
    <Button
      onPress={onPress}
      style={{
        width: '100%',
      }}>
      <View
        style={{width: '100%'}}
        direction={'row'}
        alignItems={'center'}
        justify={'between'}>
        <View
          flex={'1'}
          direction={'row'}
          justify={'between'}
          alignItems={'center'}
          style={{minHeight: segmentWrapMinHeight}}>
          {Array.from({length: SEGMENTS}, (_, index) => {
            const isLit = index < litCount;
            return (
              <View
                key={`clock-segment-${index}`}
                style={{
                  flex: 1,
                  height: segmentHeight,
                  marginHorizontal: segmentMargin,
                  borderRadius: segmentRadius,
                  backgroundColor: isLit ? activeColor : '#2A2B31',
                  opacity: isLit ? 1 : 0.98,
                }}
              />
            );
          })}
        </View>

        <Text
          color={activeColor}
          fontSize={secondsFontSize}
          fontWeight={'bold'}
          marginLeft={secondsMarginLeft}>
          {`${safeCurrent}s`}
        </Text>
      </View>
    </Button>
  );
};

export default memo(PoolShotClock);
