import {useMemo} from 'react';
import {PixelRatio, useWindowDimensions} from 'react-native';

export type WidthClass = 'compact' | 'medium' | 'expanded';
export type LayoutPreset = 'phone' | 'tablet' | 'wideTablet' | 'tv';

export type AdaptiveLayout = {
  width: number;
  height: number;
  shortSide: number;
  longSide: number;
  aspectRatio: number;
  isLandscape: boolean;
  isShortLandscape: boolean;
  isVeryShortLandscape: boolean;
  widthClass: WidthClass;
  layoutPreset: LayoutPreset;
  scale: number;
  sizeScale: number;
  textScale: number;
  styleKey: string;
  s: (value: number) => number;
  fs: (value: number, minFactor?: number, maxFactor?: number) => number;
};

const clamp = (value: number, min: number, max: number) =>
  Math.max(min, Math.min(max, value));

const round = (value: number) => PixelRatio.roundToNearestPixel(value);

export const useAdaptiveLayout = (): AdaptiveLayout => {
  const {width, height, fontScale} = useWindowDimensions();

  return useMemo(() => {
    const safeWidth = Number.isFinite(width) && width > 0 ? width : 1;
    const safeHeight = Number.isFinite(height) && height > 0 ? height : 1;
    const shortSide = Math.min(safeWidth, safeHeight);
    const longSide = Math.max(safeWidth, safeHeight);
    const aspectRatio = longSide / Math.max(shortSide, 1);
    const isLandscape = safeWidth >= safeHeight;

    const widthClass: WidthClass =
      safeWidth < 600 ? 'compact' : safeWidth < 900 ? 'medium' : 'expanded';

    const isVeryShortLandscape = isLandscape && safeHeight <= 620;
    const isShortLandscape = isLandscape && safeHeight <= 760;

    let layoutPreset: LayoutPreset = 'phone';

    if (safeWidth >= 1500 && safeHeight >= 850) {
      layoutPreset = 'tv';
    } else if (
      isLandscape &&
      ((widthClass === 'expanded' && aspectRatio >= 1.4) ||
        (widthClass === 'medium' && aspectRatio >= 1.5))
    ) {
      layoutPreset = 'wideTablet';
    } else if (widthClass === 'medium' || widthClass === 'expanded') {
      layoutPreset = 'tablet';
    }

    const widthBase =
      layoutPreset === 'tv'
        ? 1366
        : layoutPreset === 'wideTablet'
          ? 1180
          : layoutPreset === 'tablet'
            ? 1024
            : 420;

    const heightBase =
      layoutPreset === 'tv'
        ? 820
        : layoutPreset === 'wideTablet'
          ? 760
          : layoutPreset === 'tablet'
            ? 800
            : 800;

    const widthFactor = safeWidth / widthBase;
    const heightFactor = safeHeight / heightBase;
    const aspectAdjustment = isLandscape
      ? clamp((1.7 - aspectRatio) * 0.07, -0.12, 0.03)
      : clamp((1.7 - aspectRatio) * 0.03, -0.02, 0.04);

    const heightPriority = isLandscape ? 0.68 : 0.54;
    const widthPriority = 1 - heightPriority;
    const targetBase =
      widthFactor * widthPriority + heightFactor * heightPriority + aspectAdjustment;

    const compactPenalty = isVeryShortLandscape
      ? 0.14 + clamp((620 - safeHeight) / 420, 0, 0.16)
      : isShortLandscape
        ? 0.08 + clamp((760 - safeHeight) / 560, 0, 0.08)
        : 0;

    const minScale = isVeryShortLandscape
      ? 0.5
      : isShortLandscape
        ? 0.62
        : layoutPreset === 'phone'
          ? 0.78
          : 0.8;

    const maxScale = layoutPreset === 'tv' ? 1.2 : 1.08;

    const scale = clamp(targetBase - compactPenalty, minScale, maxScale);

    const textScale = clamp(
      scale / Math.min(fontScale || 1, 1.15),
      isVeryShortLandscape
        ? 0.5
        : isShortLandscape
          ? 0.62
          : layoutPreset === 'phone'
            ? 0.76
            : 0.78,
      layoutPreset === 'tv' ? 1.12 : 1.03,
    );

    const s = (value: number) => {
      const next = round(value * scale);
      return Number.isFinite(next) ? next : value;
    };

    const fs = (value: number, minFactor = 0.82, maxFactor = 1.08) => {
      const next = round(clamp(value * textScale, value * minFactor, value * maxFactor));
      return Number.isFinite(next) ? next : value;
    };

    return {
      width: safeWidth,
      height: safeHeight,
      shortSide,
      longSide,
      aspectRatio,
      isLandscape,
      isShortLandscape,
      isVeryShortLandscape,
      widthClass,
      layoutPreset,
      scale,
      sizeScale: scale,
      textScale,
      styleKey: `${Math.round(safeWidth)}x${Math.round(safeHeight)}-${layoutPreset}-${widthClass}-${isShortLandscape ? 'short' : 'normal'}-${isVeryShortLandscape ? 'vshort' : 'ok'}`,
      s,
      fs,
    };
  }, [fontScale, height, width]);
};

export default useAdaptiveLayout;
