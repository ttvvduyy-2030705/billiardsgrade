Patch files to copy into the repo root:

- android/app/src/main/java/com/aplus/score/MainApplication.kt
- android/app/src/main/java/com/aplus/score/deviceconfig/ScreenMetricsModule.kt
- android/app/src/main/java/com/aplus/score/deviceconfig/ScreenMetricsPackage.kt
- src/scenes/game/systemScreenMetrics.ts
- src/scenes/game/useAdaptiveLayout.ts
- src/scenes/game/game-play/TopMatchHeader.tsx
- src/scenes/game/game-play/PoolShotClock.tsx
- src/scenes/game/settings/index.tsx
