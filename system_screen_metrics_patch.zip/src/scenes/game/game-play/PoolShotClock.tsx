import React, {memo, useMemo} from 'react';

import Button from 'components/Button';
import Text from 'components/Text';
import View from 'components/View';
import useAdaptiveLayout from '../useAdaptiveLayout';

interface Props {
  originalCountdownTime?: number;
  currentCountdownTime: number;
  onPress?: () => void;
}

const SEGMENTS = 34;

const PoolShotClock = ({
  originalCountdownTime = 40,
  currentCountdownTime,
  onPress,
}: Props) => {
  const adaptive = useAdaptiveLayout();
  const handheldLandscape =
    adaptive.isLandscape && adaptive.systemMetrics.smallestScreenWidthDp < 600;
  const isLargeDisplay = adaptive.layoutPreset === 'tv';

  const segmentHeight = isLargeDisplay
    ? adaptive.s(92)
    : handheldLandscape
      ? adaptive.s(18)
      : adaptive.s(28);
  const segmentWrapMinHeight = isLargeDisplay
    ? adaptive.s(98)
    : handheldLandscape
      ? adaptive.s(24)
      : adaptive.s(32);
  const secondsFontSize = isLargeDisplay
    ? adaptive.fs(58, 0.9, 1.08)
    : handheldLandscape
      ? adaptive.fs(16, 0.72, 0.92)
      : adaptive.fs(20, 0.82, 0.98);
  const secondsMarginLeft = handheldLandscape ? '6' : isLargeDisplay ? '16' : '10';

  const safeOriginal = Math.max(1, originalCountdownTime || 40);
  const safeCurrent = Math.max(0, currentCountdownTime);
  const progressMax = Math.max(safeOriginal, safeCurrent);

  const activeColor =
    safeCurrent <= 5 ? '#FF2D22' : safeCurrent <= 10 ? '#FFBE2F' : '#20E247';

  const litCount = useMemo(() => {
    return Math.max(0, Math.ceil((safeCurrent / progressMax) * SEGMENTS));
  }, [safeCurrent, progressMax]);

  return (
    <Button onPress={onPress} style={{width: '100%'}}>
      <View
        style={{width: '100%'}}
        direction={'row'}
        alignItems={'center'}
        justify={'between'}>
        <View
          flex={'1'}
          direction={'row'}
          justify={'between'}
          alignItems={'center'}
          style={{minHeight: segmentWrapMinHeight}}>
          {Array.from({length: SEGMENTS}, (_, index) => {
            const isLit = index < litCount;
            return (
              <View
                key={`clock-segment-${index}`}
                style={{
                  flex: 1,
                  height: segmentHeight,
                  marginHorizontal: handheldLandscape ? 1 : 2,
                  borderRadius: isLargeDisplay ? 8 : handheldLandscape ? 3 : 4,
                  backgroundColor: isLit ? activeColor : '#2A2B31',
                  opacity: isLit ? 1 : 0.98,
                }}
              />
            );
          })}
        </View>

        <Text
          color={activeColor}
          fontSize={secondsFontSize}
          fontWeight={'bold'}
          marginLeft={secondsMarginLeft}>
          {`${safeCurrent}s`}
        </Text>
      </View>
    </Button>
  );
};

export default memo(PoolShotClock);
