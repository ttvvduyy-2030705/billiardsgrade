import React, {memo, useMemo} from 'react';
import {StyleSheet, Text as RNText} from 'react-native';

import View from 'components/View';
import Button from 'components/Button';
import Image from 'components/Image';
import Switch from 'components/Switch';

import images from 'assets';
import i18n from 'i18n';
import {
  isPoolGame,
  isPool9Game,
  isPool10Game,
  isPool15Game,
  isPool15OnlyGame,
} from 'utils/game';
import useAdaptiveLayout from '../useAdaptiveLayout';

interface Props {
  title: string;
  soundEnabled: boolean;
  onToggleSound: () => void;
  remoteEnabled?: boolean;
  onToggleRemote?: (value: boolean) => void;
  proModeEnabled?: boolean;
  onToggleProMode?: (value: boolean) => void;
  gameSettings?: any;
}

const localeText = (vi: string, en: string) => {
  const locale = String(
    (i18n as any)?.locale || (i18n as any)?.language || '',
  ).toLowerCase();
  return locale.startsWith('en') ? en : vi;
};

const TopMatchHeader = ({
  title,
  soundEnabled,
  onToggleSound,
  remoteEnabled = false,
  onToggleRemote,
  proModeEnabled = false,
  onToggleProMode,
  gameSettings,
}: Props) => {
  const isAnyPoolMode =
    isPoolGame(gameSettings?.category) ||
    isPool9Game(gameSettings?.category) ||
    isPool10Game(gameSettings?.category) ||
    isPool15Game(gameSettings?.category) ||
    isPool15OnlyGame(gameSettings?.category);

  const adaptive = useAdaptiveLayout();
  const handheldLandscape =
    adaptive.isLandscape && adaptive.systemMetrics.smallestScreenWidthDp < 600;

  const dynamicStyles = useMemo(() => {
    const clamp = (value: number, min: number, max: number) =>
      Math.max(min, Math.min(max, value));

    const scale = handheldLandscape
      ? clamp(adaptive.scale * 0.86, 0.58, 0.9)
      : clamp(adaptive.scale * 0.96, 0.72, 1.02);

    return {
      header: {
        minHeight: Math.round((handheldLandscape ? 62 : 74) * scale),
        borderRadius: Math.round((handheldLandscape ? 18 : 24) * scale),
        paddingHorizontal: Math.round((handheldLandscape ? 12 : 18) * scale),
        paddingVertical: Math.round((handheldLandscape ? 8 : 10) * scale),
      },
      logoSlot: {
        width: Math.round((handheldLandscape ? 118 : 170) * scale),
      },
      logo: {
        width: Math.round((handheldLandscape ? 70 : 98) * scale),
        height: Math.round((handheldLandscape ? 28 : 40) * scale),
      },
      titleText: {
        fontSize: Math.round((handheldLandscape ? 24 : 35) * scale),
        lineHeight: Math.round((handheldLandscape ? 28 : 40) * scale),
      },
      rightSlot: {
        width: Math.round((handheldLandscape ? 132 : isAnyPoolMode ? 188 : 224) * scale),
      },
      switchGroup: {
        width: Math.round((handheldLandscape ? 96 : isAnyPoolMode ? 138 : 172) * scale),
      },
      switchRow: {
        minHeight: Math.round((handheldLandscape ? 22 : 30) * scale),
      },
      switchLabel: {
        fontSize: Math.round((handheldLandscape ? 11 : 14) * scale),
      },
      soundButton: {
        width: Math.round((handheldLandscape ? 28 : 36) * scale),
        height: Math.round((handheldLandscape ? 28 : 36) * scale),
        marginLeft: Math.round((handheldLandscape ? 6 : 12) * scale),
      },
      soundIcon: {
        width: Math.round((handheldLandscape ? 16 : 22) * scale),
        height: Math.round((handheldLandscape ? 16 : 22) * scale),
      },
    };
  }, [adaptive.scale, handheldLandscape, isAnyPoolMode]);

  return (
    <View style={[styles.header, dynamicStyles.header]}>
      <View style={[styles.logoSlot, dynamicStyles.logoSlot]}>
        <Image
          source={images.logoSmall || images.logo}
          resizeMode="contain"
          style={[styles.logo, dynamicStyles.logo]}
        />
      </View>

      <View style={styles.titleSlot}>
        <RNText
          style={[styles.titleText, dynamicStyles.titleText]}
          numberOfLines={1}
          adjustsFontSizeToFit
          minimumFontScale={0.64}>
          {title}
        </RNText>
      </View>

      <View style={[styles.rightSlot, dynamicStyles.rightSlot]}>
        <View style={[styles.switchGroup, dynamicStyles.switchGroup]}>
          {!isAnyPoolMode ? (
            <View style={[styles.switchRow, dynamicStyles.switchRow]}>
              <RNText style={[styles.switchLabel, dynamicStyles.switchLabel]}>
                Pro Mode
              </RNText>
              <Switch
                defaultValue={proModeEnabled}
                onChange={value => onToggleProMode?.(value)}
              />
            </View>
          ) : null}

          <View style={[styles.switchRow, dynamicStyles.switchRow]}>
            <RNText style={[styles.switchLabel, dynamicStyles.switchLabel]}>
              {localeText('Điều khiển', 'Remote')}
            </RNText>
            <Switch
              defaultValue={remoteEnabled}
              onChange={value => onToggleRemote?.(value)}
            />
          </View>
        </View>

        <Button onPress={onToggleSound} style={[styles.soundButton, dynamicStyles.soundButton]}>
          <Image
            source={soundEnabled ? images.game.soundOn : images.game.soundOff}
            style={[
              styles.soundIcon,
              dynamicStyles.soundIcon,
              {tintColor: soundEnabled ? '#FFFFFF' : '#7A7A7A'},
            ]}
            resizeMode={'contain'}
          />
        </Button>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  header: {
    minHeight: 74,
    borderRadius: 24,
    borderWidth: 1.2,
    borderColor: 'rgba(255, 32, 32, 0.55)',
    backgroundColor: '#0A0B0E',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 10,
  },
  logoSlot: {
    width: 170,
    alignItems: 'flex-start',
    justifyContent: 'center',
  },
  logo: {
    width: 98,
    height: 40,
  },
  titleSlot: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  titleText: {
    color: '#FFFFFF',
    fontSize: 35,
    lineHeight: 40,
    fontWeight: '900',
    textAlign: 'center',
    includeFontPadding: false,
    width: '100%',
  },
  rightSlot: {
    width: 224,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  switchGroup: {
    width: 172,
    alignItems: 'flex-end',
    justifyContent: 'center',
  },
  switchRow: {
    minHeight: 30,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  switchLabel: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '700',
    marginRight: 6,
  },
  soundButton: {
    width: 36,
    height: 36,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 12,
  },
  soundIcon: {
    width: 22,
    height: 22,
  },
});

export default memo(TopMatchHeader);
