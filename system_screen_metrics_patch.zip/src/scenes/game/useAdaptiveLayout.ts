import {useEffect, useMemo, useState} from 'react';
import {PixelRatio, useWindowDimensions} from 'react-native';

import {
  buildFallbackSystemScreenMetrics,
  getSystemScreenMetrics,
  SystemScreenMetrics,
} from './systemScreenMetrics';

export type WidthClass = 'compact' | 'medium' | 'expanded';
export type LayoutPreset = 'phone' | 'tablet' | 'wideTablet' | 'tv';

export type AdaptiveLayout = {
  width: number;
  height: number;
  shortSide: number;
  longSide: number;
  aspectRatio: number;
  isLandscape: boolean;
  isShortLandscape: boolean;
  isVeryShortLandscape: boolean;
  widthClass: WidthClass;
  layoutPreset: LayoutPreset;
  scale: number;
  sizeScale: number;
  textScale: number;
  styleKey: string;
  systemMetrics: SystemScreenMetrics;
  s: (value: number) => number;
  fs: (value: number, minFactor?: number, maxFactor?: number) => number;
};

const clamp = (value: number, min: number, max: number) =>
  Math.max(min, Math.min(max, value));

const round = (value: number) => PixelRatio.roundToNearestPixel(value);

export const useAdaptiveLayout = (): AdaptiveLayout => {
  const {width, height, fontScale} = useWindowDimensions();
  const [systemMetrics, setSystemMetrics] = useState<SystemScreenMetrics>(() =>
    buildFallbackSystemScreenMetrics(width, height, fontScale || 1),
  );

  useEffect(() => {
    let mounted = true;

    const sync = async () => {
      const next = await getSystemScreenMetrics(width, height, fontScale || 1);
      if (mounted) {
        setSystemMetrics(next);
      }
    };

    void sync();

    return () => {
      mounted = false;
    };
  }, [width, height, fontScale]);

  return useMemo(() => {
    const safeWidth = Number.isFinite(width) && width > 0 ? width : 1;
    const safeHeight = Number.isFinite(height) && height > 0 ? height : 1;
    const shortSide = Math.min(safeWidth, safeHeight);
    const longSide = Math.max(safeWidth, safeHeight);
    const aspectRatio = longSide / Math.max(shortSide, 1);
    const isLandscape = safeWidth >= safeHeight;

    const smallestScreenWidthDp = systemMetrics.smallestScreenWidthDp || shortSide;
    const handheldSystem = smallestScreenWidthDp < 600;
    const displaySystem = smallestScreenWidthDp >= 1000 || safeWidth >= 1440;

    const widthClass: WidthClass =
      safeWidth < 600 ? 'compact' : safeWidth < 900 ? 'medium' : 'expanded';

    let layoutPreset: LayoutPreset = 'phone';
    if (displaySystem) {
      layoutPreset = 'tv';
    } else if (!handheldSystem && isLandscape && aspectRatio >= 1.42) {
      layoutPreset = 'wideTablet';
    } else if (!handheldSystem) {
      layoutPreset = 'tablet';
    }

    const heightBase =
      layoutPreset === 'tv'
        ? 760
        : layoutPreset === 'wideTablet'
          ? isLandscape
            ? 660
            : 900
          : layoutPreset === 'tablet'
            ? isLandscape
              ? 640
              : 840
            : isLandscape
              ? 500
              : 760;

    const widthBase =
      layoutPreset === 'tv'
        ? 1366
        : layoutPreset === 'wideTablet'
          ? 980
          : layoutPreset === 'tablet'
            ? 860
            : 380;

    const smallestBase =
      layoutPreset === 'tv'
        ? 1000
        : layoutPreset === 'wideTablet'
          ? 760
          : layoutPreset === 'tablet'
            ? 680
            : 360;

    const heightFactor = safeHeight / heightBase;
    const widthFactor = safeWidth / widthBase;
    const smallestFactor = smallestScreenWidthDp / smallestBase;

    const base = isLandscape
      ? heightFactor * 0.76 + widthFactor * 0.14 + smallestFactor * 0.1
      : heightFactor * 0.58 + widthFactor * 0.24 + smallestFactor * 0.18;

    let heightPenalty = 0;
    if (isLandscape && handheldSystem) {
      if (safeHeight <= 420) {
        heightPenalty += 0.18;
      } else if (safeHeight <= 470) {
        heightPenalty += 0.13;
      } else if (safeHeight <= 520) {
        heightPenalty += 0.09;
      } else if (safeHeight <= 600) {
        heightPenalty += 0.05;
      }
    } else if (isLandscape) {
      if (safeHeight <= 620) {
        heightPenalty += 0.08;
      } else if (safeHeight <= 700) {
        heightPenalty += 0.04;
      }
    }

    const aspectPenalty = isLandscape
      ? clamp(
          (aspectRatio - 1.55) * 0.12,
          0,
          handheldSystem ? 0.16 : 0.08,
        )
      : 0;

    const densityPenalty =
      isLandscape && handheldSystem && systemMetrics.densityDpi >= 260 ? 0.03 : 0;

    const floor =
      layoutPreset === 'tv'
        ? 0.9
        : handheldSystem
          ? 0.56
          : layoutPreset === 'tablet'
            ? 0.74
            : 0.78;

    const ceiling = layoutPreset === 'tv' ? 1.16 : 1.02;

    const scale = clamp(base - heightPenalty - aspectPenalty - densityPenalty, floor, ceiling);
    const textScale = clamp(
      (scale * (handheldSystem ? 0.96 : 1)) /
        Math.min(systemMetrics.fontScale || fontScale || 1, 1.15),
      handheldSystem ? 0.54 : 0.72,
      layoutPreset === 'tv' ? 1.08 : 1.02,
    );

    const isShortLandscape =
      isLandscape && safeHeight <= (handheldSystem ? 560 : 700);
    const isVeryShortLandscape =
      isLandscape && safeHeight <= (handheldSystem ? 500 : 640);

    const s = (value: number) => {
      const next = round(value * scale);
      return Number.isFinite(next) ? next : value;
    };

    const fs = (value: number, minFactor = 0.82, maxFactor = 1.08) => {
      const next = round(
        clamp(value * textScale, value * minFactor, value * maxFactor),
      );
      return Number.isFinite(next) ? next : value;
    };

    return {
      width: safeWidth,
      height: safeHeight,
      shortSide,
      longSide,
      aspectRatio,
      isLandscape,
      isShortLandscape,
      isVeryShortLandscape,
      widthClass,
      layoutPreset,
      scale,
      sizeScale: scale,
      textScale,
      styleKey: `${Math.round(safeWidth)}x${Math.round(safeHeight)}-${layoutPreset}-${widthClass}-${smallestScreenWidthDp}-${systemMetrics.densityDpi}`,
      systemMetrics,
      s,
      fs,
    };
  }, [fontScale, height, systemMetrics, width]);
};

export default useAdaptiveLayout;
