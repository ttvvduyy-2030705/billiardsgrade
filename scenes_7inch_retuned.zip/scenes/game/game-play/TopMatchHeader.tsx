import React, {memo} from 'react';
import {StyleSheet, Text as RNText, useWindowDimensions} from 'react-native';

import View from 'components/View';
import Button from 'components/Button';
import Image from 'components/Image';
import Switch from 'components/Switch';

import images from 'assets';
import colors from 'configuration/colors';
import i18n from 'i18n';
import {
  isPoolGame,
  isPool9Game,
  isPool10Game,
  isPool15Game,
  isPool15OnlyGame,
} from 'utils/game';

interface Props {
  title: string;
  soundEnabled: boolean;
  onToggleSound: () => void;
  remoteEnabled?: boolean;
  onToggleRemote?: (value: boolean) => void;
  proModeEnabled?: boolean;
  onToggleProMode?: (value: boolean) => void;
  gameSettings?: any;
}

const localeText = (vi: string, en: string) => {
  const locale = String(
    (i18n as any)?.locale || (i18n as any)?.language || '',
  ).toLowerCase();
  return locale.startsWith('en') ? en : vi;
};

const TopMatchHeader = ({
  title,
  soundEnabled,
  onToggleSound,
  remoteEnabled = false,
  onToggleRemote,
  proModeEnabled = false,
  onToggleProMode,
  gameSettings,
}: Props) => {
  const {width, height} = useWindowDimensions();
  const shortestSide = Math.min(width, height);
  const longestSide = Math.max(width, height);
  const isLandscape = width > height;
  const isLargeDisplay = longestSide >= 1600 || shortestSide >= 900;
  const isShortLandscape = isLandscape && !isLargeDisplay && height <= 900;
  const isVeryShortLandscape = isLandscape && !isLargeDisplay && height <= 760;

  const isAnyPoolMode =
    isPoolGame(gameSettings?.category) ||
    isPool9Game(gameSettings?.category) ||
    isPool10Game(gameSettings?.category) ||
    isPool15Game(gameSettings?.category) ||
    isPool15OnlyGame(gameSettings?.category);

  return (
    <View
      style={[
        styles.header,
        isShortLandscape ? styles.headerCompact : undefined,
        isVeryShortLandscape ? styles.headerVeryCompact : undefined,
      ]}>
      <View
        style={[
          styles.logoSlot,
          isShortLandscape ? styles.logoSlotCompact : undefined,
          isVeryShortLandscape ? styles.logoSlotVeryCompact : undefined,
        ]}>
        <Image
          source={images.logoSmall || images.logo}
          resizeMode="contain"
          style={[styles.logo, isShortLandscape ? styles.logoCompact : undefined, isVeryShortLandscape ? styles.logoVeryCompact : undefined]}
        />
      </View>

      <View style={styles.titleSlot}>
        <RNText
          numberOfLines={1}
          adjustsFontSizeToFit
          minimumFontScale={0.72}
          style={[
            styles.titleText,
            isShortLandscape ? styles.titleTextCompact : undefined,
            isVeryShortLandscape ? styles.titleTextVeryCompact : undefined,
          ]}>
          {title}
        </RNText>
      </View>

      <View
        style={[
          styles.rightSlot,
          isShortLandscape ? styles.rightSlotCompact : undefined,
          isVeryShortLandscape ? styles.rightSlotVeryCompact : undefined,
        ]}>
        <View
          style={[
            styles.switchGroup,
            isShortLandscape ? styles.switchGroupCompact : undefined,
            isVeryShortLandscape ? styles.switchGroupVeryCompact : undefined,
          ]}>
          {!isAnyPoolMode ? (
            <View style={[styles.switchRow, isShortLandscape ? styles.switchRowCompact : undefined, isVeryShortLandscape ? styles.switchRowVeryCompact : undefined]}>
              <RNText style={[styles.switchLabel, isShortLandscape ? styles.switchLabelCompact : undefined, isVeryShortLandscape ? styles.switchLabelVeryCompact : undefined]}>Pro Mode</RNText>
              <Switch
                defaultValue={proModeEnabled}
                onChange={value => onToggleProMode?.(value)}
              />
            </View>
          ) : null}

          <View style={[styles.switchRow, isShortLandscape ? styles.switchRowCompact : undefined, isVeryShortLandscape ? styles.switchRowVeryCompact : undefined]}>
            <RNText style={[styles.switchLabel, isShortLandscape ? styles.switchLabelCompact : undefined, isVeryShortLandscape ? styles.switchLabelVeryCompact : undefined]}>
              {localeText('Điều khiển', 'Remote')}
            </RNText>
            <Switch
              defaultValue={remoteEnabled}
              onChange={value => onToggleRemote?.(value)}
            />
          </View>
        </View>

        <Button onPress={onToggleSound} style={[styles.soundButton, isShortLandscape ? styles.soundButtonCompact : undefined, isVeryShortLandscape ? styles.soundButtonVeryCompact : undefined]}>
          <Image
            source={soundEnabled ? images.game.soundOn : images.game.soundOff}
            style={[
              styles.soundIcon,
              isShortLandscape ? styles.soundIconCompact : undefined,
              isVeryShortLandscape ? styles.soundIconVeryCompact : undefined,
              {tintColor: soundEnabled ? '#FFFFFF' : '#7A7A7A'},
            ]}
            resizeMode={'contain'}
          />
        </Button>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  header: {
    minHeight: 74,
    borderRadius: 24,
    borderWidth: 1.2,
    borderColor: 'rgba(255, 32, 32, 0.55)',
    backgroundColor: '#0A0B0E',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 10,
    shadowColor: '#ff1f1f',
    shadowOpacity: 0.18,
    shadowRadius: 14,
    shadowOffset: {width: 0, height: 0},
    elevation: 10,
  },

  headerCompact: {
    minHeight: 58,
    borderRadius: 18,
    paddingHorizontal: 12,
    paddingVertical: 7,
  },

  headerVeryCompact: {
    minHeight: 52,
    borderRadius: 16,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },

  logoSlot: {
    width: 170,
    alignItems: 'flex-start',
    justifyContent: 'center',
  },

  logoSlotCompact: {
    width: 110,
  },

  logoSlotVeryCompact: {
    width: 92,
  },

  logo: {
    width: 98,
    height: 40,
  },

  logoCompact: {
    width: 72,
    height: 28,
  },

  logoVeryCompact: {
    width: 60,
    height: 24,
  },

  titleSlot: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },

  titleText: {
    color: '#FFFFFF',
    fontSize: 35,
    lineHeight: 40,
    fontWeight: '900',
    textAlign: 'center',
    includeFontPadding: false,
    width: '100%',
  },

  titleTextCompact: {
    fontSize: 24,
    lineHeight: 28,
  },

  titleTextVeryCompact: {
    fontSize: 20,
    lineHeight: 24,
  },

  rightSlot: {
    width: 224,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },

  rightSlotCompact: {
    width: 170,
  },

  rightSlotVeryCompact: {
    width: 150,
  },

  switchGroup: {
    width: 172,
  },

  switchGroupCompact: {
    width: 136,
  },

  switchGroupVeryCompact: {
    width: 122,
  },

  switchRow: {
    minHeight: 30,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  switchRowCompact: {
    minHeight: 24,
  },

  switchRowVeryCompact: {
    minHeight: 22,
  },

  switchLabel: {
    color: colors.white,
    fontSize: 14,
    fontWeight: '600',
  },

  switchLabelCompact: {
    fontSize: 11,
  },

  switchLabelVeryCompact: {
    fontSize: 10,
  },

  soundButton: {
    width: 36,
    height: 36,
    marginLeft: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },

  soundButtonCompact: {
    width: 30,
    height: 30,
    marginLeft: 8,
  },

  soundButtonVeryCompact: {
    width: 26,
    height: 26,
    marginLeft: 6,
  },

  soundIcon: {
    width: 22,
    height: 22,
    tintColor: '#FFFFFF',
  },

  soundIconCompact: {
    width: 18,
    height: 18,
  },

  soundIconVeryCompact: {
    width: 16,
    height: 16,
  },
});

export default memo(TopMatchHeader);
