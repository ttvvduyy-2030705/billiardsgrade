import React, {memo, useMemo} from 'react';
import {useWindowDimensions} from 'react-native';

import Button from 'components/Button';
import Text from 'components/Text';
import View from 'components/View';

interface Props {
  originalCountdownTime?: number;
  currentCountdownTime: number;
  onPress?: () => void;
}

const SEGMENTS = 34;

const PoolShotClock = ({
  originalCountdownTime = 40,
  currentCountdownTime,
  onPress,
}: Props) => {
  const {width, height} = useWindowDimensions();
  const shortestSide = Math.min(width, height);
  const longestSide = Math.max(width, height);
  const isLandscape = width > height;
  const isLargeDisplay = longestSide >= 1600 || shortestSide >= 900;
  const isShortLandscape = isLandscape && !isLargeDisplay && height <= 900;
  const isVeryShortLandscape = isLandscape && !isLargeDisplay && height <= 760;
  const segmentHeight = isLargeDisplay
    ? 92
    : isVeryShortLandscape
    ? 16
    : isShortLandscape
    ? 20
    : 28;
  const segmentWrapMinHeight = isLargeDisplay
    ? 98
    : isVeryShortLandscape
    ? 20
    : isShortLandscape
    ? 24
    : 32;
  const secondsFontSize = isLargeDisplay
    ? 58
    : isVeryShortLandscape
    ? 12
    : isShortLandscape
    ? 16
    : 20;
  const secondsMarginLeft = isLargeDisplay ? '16' : isVeryShortLandscape ? '4' : isShortLandscape ? '6' : '10';
  const segmentMargin = isVeryShortLandscape ? 1 : 2;
  const segmentRadius = isLargeDisplay ? 8 : isVeryShortLandscape ? 3 : 4;

  const safeOriginal = Math.max(1, originalCountdownTime || 40);
  const safeCurrent = Math.max(0, currentCountdownTime);
  const progressMax = Math.max(safeOriginal, safeCurrent);

  const activeColor =
    safeCurrent <= 5 ? '#FF2D22' : safeCurrent <= 10 ? '#FFBE2F' : '#20E247';

  const litCount = useMemo(() => {
    return Math.max(0, Math.ceil((safeCurrent / progressMax) * SEGMENTS));
  }, [safeCurrent, progressMax]);

  return (
    <Button
      onPress={onPress}
      style={{
        width: '100%',
        paddingTop: isLargeDisplay ? 0 : 0,
        paddingBottom: isLargeDisplay ? 0 : 0,
      }}>
      <View
        style={{width: '100%'}}
        direction={'row'}
        alignItems={'center'}
        justify={'between'}>
        <View
          flex={'1'}
          direction={'row'}
          justify={'between'}
          alignItems={'center'}
          style={{minHeight: segmentWrapMinHeight}}>
          {Array.from({length: SEGMENTS}, (_, index) => {
            const isLit = index < litCount;
            return (
              <View
                key={`clock-segment-${index}`}
                style={{
                  flex: 1,
                  height: segmentHeight,
                  marginHorizontal: segmentMargin,
                  borderRadius: segmentRadius,
                  backgroundColor: isLit ? activeColor : '#2A2B31',
                  opacity: isLit ? 1 : 0.98,
                }}
              />
            );
          })}
        </View>

        <Text
          color={activeColor}
          fontSize={secondsFontSize}
          fontWeight={'bold'}
          marginLeft={secondsMarginLeft}>
          {`${safeCurrent}s`}
        </Text>
      </View>
    </Button>
  );
};

export default memo(PoolShotClock);
