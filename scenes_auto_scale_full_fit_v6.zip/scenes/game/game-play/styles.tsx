import {StyleSheet} from 'react-native';

import colors from 'configuration/colors';

import {AdaptiveLayout} from '../useAdaptiveLayout';

const createStyles = (a: AdaptiveLayout) => {
  const boardGap =
    a.isVeryShortLandscape ? a.s(4) : a.isShortLandscape ? a.s(6) : a.layoutPreset === 'phone' ? a.s(8) : a.s(12);
  const shortLandscape = a.isLandscape && a.height <= 760;
  const screenHorizontal =
    a.isVeryShortLandscape
      ? a.s(3)
      : shortLandscape
        ? a.s(5)
        : a.layoutPreset === 'tv'
          ? a.s(16)
          : a.layoutPreset === 'wideTablet'
            ? a.s(12)
            : a.layoutPreset === 'tablet'
              ? a.s(10)
              : a.s(8);

  return StyleSheet.create({
    warmUpContainer: {
      ...StyleSheet.absoluteFillObject,
      backgroundColor: colors.overlay,
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 40,
    },

    buttonEndWarmUp: {
      backgroundColor: '#131313',
      borderRadius: a.s(20),
    },

    countdownContainer: {
      width: '100%',
      paddingHorizontal: a.isVeryShortLandscape ? a.s(0) : a.s(2),
      paddingTop: 0,
      paddingBottom: 0,
      marginTop: a.isVeryShortLandscape ? -4 : -2,
      backgroundColor: '#000000',
    },

    mainArea: {
      flex: 1,
      paddingTop: a.isVeryShortLandscape ? a.s(2) : shortLandscape ? a.s(4) : a.layoutPreset === 'phone' ? a.s(6) : a.s(8),
    },

    mainAreaFullscreen: {
      flex: 1,
      paddingTop: 0,
    },

    poolArenaScreen: {
      backgroundColor: '#000000',
      paddingHorizontal: screenHorizontal,
      paddingTop: a.isVeryShortLandscape ? a.s(2) : shortLandscape ? a.s(4) : a.layoutPreset === 'phone' ? a.s(8) : a.s(10),
      paddingBottom: 0,
    },

    poolArenaBoard: {
      gap: boardGap,
    },

    poolArenaPlayerColumn: {
      flex: 1,
      minWidth: 0,
    },

    poolArenaConsoleWrapper: {
      flex:
        a.isVeryShortLandscape
          ? 1.22
          : a.isShortLandscape
            ? 1.16
            : a.layoutPreset === 'wideTablet'
              ? 1.08
              : a.layoutPreset === 'phone'
                ? 1.06
                : 0.98,
      minWidth: 0,
      marginHorizontal: 0,
      paddingBottom: 0,
    },
  });
};

export default createStyles;
