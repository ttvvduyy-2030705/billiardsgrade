import React, {memo, useMemo, useState} from 'react';
import {
  LayoutChangeEvent,
  StyleProp,
  StyleSheet,
  View,
  ViewStyle,
} from 'react-native';

type Props = {
  enabled?: boolean;
  idealHeight?: number;
  idealWidth?: number;
  minScale?: number;
  style?: StyleProp<ViewStyle>;
  children: React.ReactNode;
};

const clamp = (value: number, min: number, max: number) =>
  Math.max(min, Math.min(max, value));

const AutoFitStage = ({
  enabled = true,
  idealHeight = 760,
  idealWidth,
  minScale = 0.72,
  style,
  children,
}: Props) => {
  const [size, setSize] = useState({width: 0, height: 0});

  const scale = useMemo(() => {
    if (!enabled || !size.width || !size.height) {
      return 1;
    }

    const heightScale = size.height / Math.max(idealHeight, 1);
    const widthScale = idealWidth ? size.width / Math.max(idealWidth, 1) : 1;

    return clamp(Math.min(1, heightScale, widthScale), minScale, 1);
  }, [enabled, idealHeight, idealWidth, minScale, size.height, size.width]);

  const handleLayout = (event: LayoutChangeEvent) => {
    const {width, height} = event.nativeEvent.layout;

    if (
      Math.round(width) !== Math.round(size.width) ||
      Math.round(height) !== Math.round(size.height)
    ) {
      setSize({width, height});
    }
  };

  if (!enabled) {
    return (
      <View style={[styles.viewport, style]} onLayout={handleLayout}>
        {children}
      </View>
    );
  }

  return (
    <View style={[styles.viewport, style]} onLayout={handleLayout}>
      {!size.width || !size.height || scale >= 0.999 ? (
        children
      ) : (
        <View style={styles.centerWrap} pointerEvents="box-none">
          <View
            pointerEvents="box-none"
            style={[
              styles.canvas,
              {
                width: size.width / scale,
                height: size.height / scale,
                transform: [{scale}],
              },
            ]}>
            <View style={styles.fill}>{children}</View>
          </View>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  viewport: {
    flex: 1,
    width: '100%',
    overflow: 'hidden',
  },
  centerWrap: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  canvas: {
    alignSelf: 'center',
  },
  fill: {
    width: '100%',
    height: '100%',
  },
});

export default memo(AutoFitStage);
