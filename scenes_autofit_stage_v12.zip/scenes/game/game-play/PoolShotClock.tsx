import React, {memo, useMemo} from 'react';

import Button from 'components/Button';
import Text from 'components/Text';
import View from 'components/View';

import useAdaptiveLayout from '../useAdaptiveLayout';

interface Props {
  originalCountdownTime?: number;
  currentCountdownTime: number;
  onPress?: () => void;
}

const SEGMENTS = 34;

const clamp = (value: number, min: number, max: number) =>
  Math.max(min, Math.min(max, value));

const PoolShotClock = ({
  originalCountdownTime = 40,
  currentCountdownTime,
  onPress,
}: Props) => {
  const adaptive = useAdaptiveLayout();
  const isLargeDisplay = adaptive.layoutPreset === 'tv';
  const shortLandscapePenalty = adaptive.isLandscape
    ? clamp((720 - adaptive.height) / 260, 0, 0.22)
    : 0;
  const ratioPenalty = adaptive.isLandscape
    ? clamp((adaptive.aspectRatio - 1.65) * 0.08, 0, 0.08)
    : 0;
  const uiScale = clamp(
    adaptive.textScale - shortLandscapePenalty - ratioPenalty,
    adaptive.isLandscape ? 0.7 : 0.82,
    isLargeDisplay ? 1.12 : 1,
  );

  const segmentHeight = Math.round((isLargeDisplay ? 92 : 28) * uiScale);
  const segmentWrapMinHeight = Math.round((isLargeDisplay ? 98 : 32) * uiScale);
  const secondsFontSize = Math.round((isLargeDisplay ? 58 : 20) * uiScale);
  const secondsMarginLeft = Math.round((isLargeDisplay ? 16 : 10) * uiScale);
  const segmentGap = Math.max(1, Math.round(2 * uiScale));
  const segmentRadius = Math.max(3, Math.round((isLargeDisplay ? 8 : 4) * uiScale));

  const safeOriginal = Math.max(1, originalCountdownTime || 40);
  const safeCurrent = Math.max(0, currentCountdownTime);
  const progressMax = Math.max(safeOriginal, safeCurrent);

  const activeColor =
    safeCurrent <= 5 ? '#FF2D22' : safeCurrent <= 10 ? '#FFBE2F' : '#20E247';

  const litCount = useMemo(() => {
    return Math.max(0, Math.ceil((safeCurrent / progressMax) * SEGMENTS));
  }, [safeCurrent, progressMax]);

  return (
    <Button
      onPress={onPress}
      style={{
        width: '100%',
        paddingTop: 0,
        paddingBottom: 0,
      }}>
      <View
        style={{width: '100%'}}
        direction={'row'}
        alignItems={'center'}
        justify={'between'}>
        <View
          flex={'1'}
          direction={'row'}
          justify={'between'}
          alignItems={'center'}
          style={{minHeight: segmentWrapMinHeight}}>
          {Array.from({length: SEGMENTS}, (_, index) => {
            const isLit = index < litCount;
            return (
              <View
                key={`clock-segment-${index}`}
                style={{
                  flex: 1,
                  height: segmentHeight,
                  marginHorizontal: segmentGap,
                  borderRadius: segmentRadius,
                  backgroundColor: isLit ? activeColor : '#2A2B31',
                  opacity: isLit ? 1 : 0.98,
                }}
              />
            );
          })}
        </View>

        <Text
          color={activeColor}
          fontSize={secondsFontSize}
          fontWeight={'bold'}
          marginLeft={String(secondsMarginLeft)}>
          {`${safeCurrent}s`}
        </Text>
      </View>
    </Button>
  );
};

export default memo(PoolShotClock);
