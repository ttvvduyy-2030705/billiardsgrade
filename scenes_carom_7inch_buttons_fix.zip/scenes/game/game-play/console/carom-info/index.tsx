import React, {memo, useCallback} from 'react';
import {Image as RNImage, TextStyle, useWindowDimensions} from 'react-native';
import View from 'components/View';
import Text from 'components/Text';
import Image from 'components/Image';
import Countdown from 'components/Countdown';
import colors from 'configuration/colors';
import {Player} from 'types/player';

import {dims} from 'configuration';
import images from 'assets';
import CaromInfoViewModel, {Props} from './CaromInfoViewModel';
import styles from './styles';
import {getCountryFlagImageUri} from '../../../settings/player/countries';


const isRemoteUri = (value?: string) => /^https?:\/\//i.test(String(value || '').trim());

const getPlayerFlagImageUri = (player?: {countryCode?: string; flag?: string}) => {
  const fromCode = getCountryFlagImageUri(player?.countryCode, 80);
  if (fromCode) {
    return fromCode;
  }

  const rawFlag = String(player?.flag || '').trim();
  return isRemoteUri(rawFlag) ? rawFlag : '';
};

const getPlayerFlagText = (player?: {flag?: string}) => {
  const rawFlag = String(player?.flag || '').trim();
  return isRemoteUri(rawFlag) ? '' : rawFlag;
};

const CaromInfo = (props: Props) => {
  const viewModel = CaromInfoViewModel(props);
  const isLibre = props.gameSettings?.category === 'libre';
  const {width, height} = useWindowDimensions();
  const isLandscape = width > height;
  const useCompactLayout = isLandscape && width <= 1400 && height <= 900;
  const useVeryCompactLayout = isLandscape && width <= 1280 && height <= 820;
  const turnFontSize = useVeryCompactLayout ? 34 : useCompactLayout ? 42 : 56;
  const turnLineHeight = useVeryCompactLayout ? 40 : useCompactLayout ? 48 : 70;
  const nameFontSize = useVeryCompactLayout ? 16 : useCompactLayout ? 18 : 22;
  const pointFontSize = useVeryCompactLayout ? 24 : useCompactLayout ? 28 : 32;
  const countdownLabelSize = useVeryCompactLayout ? 14 : useCompactLayout ? 16 : 20;
  const countdownWidth = width * (useVeryCompactLayout ? 0.18 : useCompactLayout ? 0.21 : 0.28);
  const countdownHeightItem = useVeryCompactLayout ? 16 : useCompactLayout ? 20 : 27;

  const getTotalPointFont = useCallback(
    (point: number) => {
      const value = Number(point || 0);

      if (!isLibre) {
        return useVeryCompactLayout
          ? {fontSize: 24, lineHeight: 28}
          : useCompactLayout
          ? {fontSize: 28, lineHeight: 32}
          : {fontSize: 40, lineHeight: 46};
      }

      if (value >= 1000) {
        return useVeryCompactLayout
          ? {fontSize: 16, lineHeight: 20}
          : useCompactLayout
          ? {fontSize: 18, lineHeight: 22}
          : {fontSize: 22, lineHeight: 26};
      }

      if (value >= 100) {
        return useVeryCompactLayout
          ? {fontSize: 20, lineHeight: 24}
          : useCompactLayout
          ? {fontSize: 24, lineHeight: 28}
          : {fontSize: 30, lineHeight: 34};
      }

      return useVeryCompactLayout
        ? {fontSize: 24, lineHeight: 28}
        : useCompactLayout
        ? {fontSize: 28, lineHeight: 32}
        : {fontSize: 40, lineHeight: 46};
    },
    [isLibre, useCompactLayout, useVeryCompactLayout],
  );

  const renderPlayer = useCallback(
    (player: Player, index: number, totalPointStyle: TextStyle) => {
      const totalPointValue = Number(player.totalPoint || 0);
      const totalPointFont = getTotalPointFont(totalPointValue);

      const playerFlag = getPlayerFlagText(player as any);
      const playerFlagImage = getPlayerFlagImageUri(player as any);

      return (
        <View
          style={{backgroundColor: player.color}}
          direction={'row'}
          alignItems={'center'}>
          <View
            direction={'row'}
            alignItems={'center'}
            paddingLeft={useVeryCompactLayout ? '6' : useCompactLayout ? '8' : '10'}>
            {playerFlagImage || playerFlag ? (
              <View
                style={[
                  styles.flagBadge,
                  useCompactLayout
                    ? {
                        width: useVeryCompactLayout ? 22 : 28,
                        height: useVeryCompactLayout ? 16 : 20,
                        marginRight: useVeryCompactLayout ? 5 : 6,
                      }
                    : undefined,
                ]}>
                {playerFlagImage ? (
                  <RNImage
                    source={{uri: playerFlagImage}}
                    resizeMode="cover"
                    fadeDuration={0}
                    style={{width: '100%', height: '100%', backgroundColor: '#FFFFFF'}}
                  />
                ) : (
                  <Text
                    style={[
                      styles.flagText,
                      useCompactLayout
                        ? {fontSize: useVeryCompactLayout ? 9 : 11, lineHeight: useVeryCompactLayout ? 10 : 12}
                        : undefined,
                    ]}>
                    {playerFlag}
                  </Text>
                )}
              </View>
            ) : null}

            <View
              flex={'1'}
              style={[
                playerFlag ? styles.nameWithFlag : undefined,
                useCompactLayout ? {marginRight: 4} : undefined,
              ]}>
              <Text fontSize={nameFontSize} fontWeight={'900'} numberOfLines={1}>
                {player.name.toUpperCase()}
              </Text>
            </View>

            {props.currentPlayerIndex === index ? (
              <Image
                source={images.game.turn}
                style={[
                  styles.turnImage,
                  useCompactLayout
                    ? {
                        width: useVeryCompactLayout ? 18 : 22,
                        height: useVeryCompactLayout ? 18 : 22,
                        marginLeft: useVeryCompactLayout ? 4 : 6,
                        marginRight: useVeryCompactLayout ? -2 : -3,
                      }
                    : undefined,
                ]}
              />
            ) : (
              <View
                style={[
                  styles.empty,
                  useCompactLayout
                    ? {
                        width: useVeryCompactLayout ? 18 : 22,
                        height: useVeryCompactLayout ? 18 : 22,
                        marginLeft: useVeryCompactLayout ? 4 : 6,
                      }
                    : undefined,
                ]}
              />
            )}

            <View direction={'row'} alignItems={'end'}>
              <View
                style={[
                  styles.totalPointWrapper,
                  useCompactLayout
                    ? {minWidth: useVeryCompactLayout ? 38 : 46}
                    : undefined,
                ]}
                paddingHorizontal={useVeryCompactLayout ? '5' : useCompactLayout ? '6' : '10'}>
                <Text
                  style={totalPointStyle}
                  fontSize={totalPointFont.fontSize}
                  lineHeight={totalPointFont.lineHeight}
                  fontWeight={'bold'}
                  color={colors.white}
                  numberOfLines={1}>
                  {totalPointValue}
                </Text>
              </View>

              <View
                style={[
                  styles.currentTotalPoint,
                  useCompactLayout
                    ? {minWidth: useVeryCompactLayout ? 26 : 30}
                    : undefined,
                ]}
                paddingHorizontal={useVeryCompactLayout ? '4' : useCompactLayout ? '5' : '10'}>
                <Text
                  style={styles.currentPointText}
                  fontSize={pointFontSize}
                  lineHeight={pointFontSize + 4}
                  fontWeight={'bold'}>
                  {player.proMode?.currentPoint || 0}
                </Text>
              </View>
            </View>
          </View>
        </View>
      );
    },
    [
      getTotalPointFont,
      nameFontSize,
      pointFontSize,
      props.currentPlayerIndex,
      useCompactLayout,
      useVeryCompactLayout,
    ],
  );

  if (!props.gameSettings.mode?.countdownTime) {
    return <View />;
  }

  return (
    <View
      style={styles.container}
      direction={'row'}
      marginTop={useCompactLayout ? '4' : '10'}>
      <View flex={'1'}>
        <View
          collapsable={false}
          style={styles.countdownContainer}
          direction={'row'}>
          <View>
            <View
              flex={'1'}
              justify={'center'}
              style={styles.totalTurnWrapper}
              paddingHorizontal={useVeryCompactLayout ? '10' : useCompactLayout ? '14' : '20'}>
              <Text color={colors.white} fontSize={turnFontSize} lineHeight={turnLineHeight}>
                {Math.max(1, Number(props.totalTurns || 1))}
              </Text>
            </View>
          </View>

          <View flex={'1'}>
            {renderPlayer(viewModel.player0, 0, styles.totalPointText0)}
            {renderPlayer(viewModel.player1, 1, styles.totalPointText1)}
          </View>
        </View>

        <View
          collapsable={false}
          style={styles.countdownContainer}
          direction={'row'}
          alignItems={'center'}>
          <View
            style={styles.countdownWrapper}
            paddingHorizontal={useVeryCompactLayout ? '10' : useCompactLayout ? '14' : '20'}
            marginLeft={useCompactLayout ? '2' : '5'}>
            <Text fontSize={countdownLabelSize} color={colors.white}>
              {props.countdownTime}
            </Text>
          </View>

          <View flex={'1'} direction={'row'}>
            <Countdown
              originalCountdownTime={props.gameSettings.mode?.countdownTime}
              currentCountdownTime={props.countdownTime}
              countdownWidth={countdownWidth}
              heightItem={countdownHeightItem}
              marginHorizontal={2}
              direction="right-to-left"
              colorMode="threshold"
              yellowThreshold={10}
              redThreshold={5}
            />
          </View>
        </View>
      </View>
    </View>
  );
};

export default memo(CaromInfo);