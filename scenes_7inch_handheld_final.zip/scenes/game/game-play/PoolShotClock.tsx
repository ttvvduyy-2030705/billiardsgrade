import React, {memo, useMemo} from 'react';
import {useWindowDimensions} from 'react-native';

import Button from 'components/Button';
import Text from 'components/Text';
import View from 'components/View';

interface Props {
  originalCountdownTime?: number;
  currentCountdownTime: number;
  onPress?: () => void;
}

const SEGMENTS = 34;

const PoolShotClock = ({
  originalCountdownTime = 40,
  currentCountdownTime,
  onPress,
}: Props) => {
  const {width, height} = useWindowDimensions();
  const shortestSide = Math.min(width, height);
  const isLandscape = width > height;
  const isLargeDisplay = width >= 1800 || shortestSide >= 1100;
  const isCondensedLandscape =
    isLandscape && (height <= 980 || (width <= 1500 && shortestSide <= 1000));
  const isHandheldLandscape =
    isLandscape && Math.max(width, height) <= 1400 && height <= 900;
  const isShortLandscapeDisplay =
    isLandscape && (height <= 840 || (width <= 1400 && shortestSide <= 920) || isHandheldLandscape);
  const isVeryShortLandscapeDisplay =
    isLandscape && (height <= 760 || (width <= 1280 && shortestSide <= 860) || isHandheldLandscape);
  const segmentHeight = isLargeDisplay
    ? 82
    : isVeryShortLandscapeDisplay
    ? 8
    : isShortLandscapeDisplay
    ? 12
    : isCondensedLandscape
    ? 14
    : 22;
  const segmentWrapMinHeight = isLargeDisplay
    ? 86
    : isVeryShortLandscapeDisplay
    ? 11
    : isShortLandscapeDisplay
    ? 16
    : isCondensedLandscape
    ? 18
    : 26;
  const secondsFontSize = isLargeDisplay
    ? 48
    : isVeryShortLandscapeDisplay
    ? 8
    : isShortLandscapeDisplay
    ? 12
    : isCondensedLandscape
    ? 14
    : 18;
  const secondsMarginLeft = isLargeDisplay
    ? '12'
    : isShortLandscapeDisplay
    ? '3'
    : isCondensedLandscape
    ? '4'
    : '8';

  const safeOriginal = Math.max(1, originalCountdownTime || 40);
  const safeCurrent = Math.max(0, currentCountdownTime);
  const progressMax = Math.max(safeOriginal, safeCurrent);

  const activeColor =
    safeCurrent <= 5 ? '#FF2D22' : safeCurrent <= 10 ? '#FFBE2F' : '#20E247';

  const litCount = useMemo(() => {
    return Math.max(0, Math.ceil((safeCurrent / progressMax) * SEGMENTS));
  }, [safeCurrent, progressMax]);

  return (
    <Button
      onPress={onPress}
      style={{
        width: '100%',
        paddingTop: isLargeDisplay ? 0 : 0,
        paddingBottom: isLargeDisplay ? 0 : 0,
      }}>
      <View
        style={{width: '100%'}}
        direction={'row'}
        alignItems={'center'}
        justify={'between'}>
        <View
          flex={'1'}
          direction={'row'}
          justify={'between'}
          alignItems={'center'}
          style={{minHeight: segmentWrapMinHeight}}>
          {Array.from({length: SEGMENTS}, (_, index) => {
            const isLit = index < litCount;
            return (
              <View
                key={`clock-segment-${index}`}
                style={{
                  flex: 1,
                  height: segmentHeight,
                  marginHorizontal: isVeryShortLandscapeDisplay ? 1 : isCondensedLandscape ? 1.5 : 2,
                  borderRadius: isLargeDisplay ? 8 : isCondensedLandscape ? 3 : 4,
                  backgroundColor: isLit ? activeColor : '#2A2B31',
                  opacity: isLit ? 1 : 0.98,
                }}
              />
            );
          })}
        </View>

        <Text
          color={activeColor}
          fontSize={secondsFontSize}
          fontWeight={'bold'}
          marginLeft={secondsMarginLeft}>
          {`${safeCurrent}s`}
        </Text>
      </View>
    </Button>
  );
};

export default memo(PoolShotClock);
