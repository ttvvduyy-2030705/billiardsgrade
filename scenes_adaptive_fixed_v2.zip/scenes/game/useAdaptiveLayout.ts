import {useMemo} from 'react';
import {PixelRatio, useWindowDimensions} from 'react-native';

export type WidthClass = 'compact' | 'medium' | 'expanded';
export type LayoutPreset = 'phone' | 'tablet' | 'wideTablet' | 'tv';

export type AdaptiveLayout = {
  width: number;
  height: number;
  shortSide: number;
  longSide: number;
  aspectRatio: number;
  isLandscape: boolean;
  widthClass: WidthClass;
  layoutPreset: LayoutPreset;
  scale: number;
  textScale: number;
  styleKey: string;
  s: (value: number) => number;
  fs: (value: number, minFactor?: number, maxFactor?: number) => number;
};

const clamp = (value: number, min: number, max: number) =>
  Math.max(min, Math.min(max, value));

const round = (value: number) => PixelRatio.roundToNearestPixel(value);

export const useAdaptiveLayout = (): AdaptiveLayout => {
  const {width, height, fontScale} = useWindowDimensions();

  return useMemo(() => {
    const shortSide = Math.min(width, height);
    const longSide = Math.max(width, height);
    const aspectRatio = longSide / Math.max(shortSide, 1);
    const isLandscape = width > height;

    const widthClass: WidthClass =
      width < 600 ? 'compact' : width < 900 ? 'medium' : 'expanded';

    let layoutPreset: LayoutPreset = 'phone';

    if (widthClass === 'expanded' && (width >= 1366 || shortSide >= 900)) {
      layoutPreset = 'tv';
    } else if (
      isLandscape &&
      ((widthClass === 'expanded' && aspectRatio >= 1.45) ||
        (widthClass === 'medium' && aspectRatio >= 1.5))
    ) {
      layoutPreset = 'wideTablet';
    } else if (widthClass === 'medium' || widthClass === 'expanded') {
      layoutPreset = 'tablet';
    }

    const widthBase =
      layoutPreset === 'tv'
        ? 1366
        : layoutPreset === 'wideTablet'
          ? 1180
          : layoutPreset === 'tablet'
            ? 1024
            : 420;

    const heightBase =
      layoutPreset === 'tv'
        ? 768
        : layoutPreset === 'wideTablet'
          ? 720
          : layoutPreset === 'tablet'
            ? 760
            : 800;

    const widthFactor = width / widthBase;
    const heightFactor = height / heightBase;
    const aspectBias = isLandscape
      ? clamp((aspectRatio - 1.35) * 0.08, -0.03, 0.05)
      : clamp((1.7 - aspectRatio) * 0.03, -0.02, 0.04);

    const targetBase = widthFactor * 0.68 + heightFactor * 0.32 + aspectBias;

    const scale = clamp(
      targetBase,
      layoutPreset === 'phone' ? 0.88 : 0.84,
      layoutPreset === 'tv' ? 1.2 : 1.1,
    );

    const textScale = clamp(
      scale / Math.min(fontScale || 1, 1.15),
      layoutPreset === 'phone' ? 0.86 : 0.82,
      layoutPreset === 'tv' ? 1.12 : 1.06,
    );

    const s = (value: number) => round(value * scale);
    const fs = (value: number, minFactor = 0.84, maxFactor = 1.08) =>
      round(clamp(value * textScale, value * minFactor, value * maxFactor));

    return {
      width,
      height,
      shortSide,
      longSide,
      aspectRatio,
      isLandscape,
      widthClass,
      layoutPreset,
      scale,
      textScale,
      styleKey: `${Math.round(width)}x${Math.round(height)}-${layoutPreset}-${widthClass}`,
      s,
      fs,
    };
  }, [fontScale, height, width]);
};

export default useAdaptiveLayout;
