import {useMemo} from 'react';
import {PixelRatio, useWindowDimensions} from 'react-native';

export type WidthClass = 'compact' | 'medium' | 'expanded';
export type LayoutPreset = 'phone' | 'tablet' | 'wideTablet' | 'tv';

export type AdaptiveLayout = {
  width: number;
  height: number;
  shortSide: number;
  longSide: number;
  aspectRatio: number;
  isLandscape: boolean;
  isShortLandscape: boolean;
  isVeryShortLandscape: boolean;
  widthClass: WidthClass;
  layoutPreset: LayoutPreset;
  scale: number;
  sizeScale: number;
  textScale: number;
  styleKey: string;
  s: (value: number) => number;
  fs: (value: number, minFactor?: number, maxFactor?: number) => number;
};

const clamp = (value: number, min: number, max: number) =>
  Math.max(min, Math.min(max, value));

const round = (value: number) => PixelRatio.roundToNearestPixel(value);

export const useAdaptiveLayout = (): AdaptiveLayout => {
  const {width, height, fontScale} = useWindowDimensions();

  return useMemo(() => {
    const safeWidth = Number.isFinite(width) && width > 0 ? width : 1;
    const safeHeight = Number.isFinite(height) && height > 0 ? height : 1;
    const shortSide = Math.min(safeWidth, safeHeight);
    const longSide = Math.max(safeWidth, safeHeight);
    const aspectRatio = longSide / Math.max(shortSide, 1);
    const isLandscape = safeWidth >= safeHeight;

    const widthClass: WidthClass =
      safeWidth < 600 ? 'compact' : safeWidth < 900 ? 'medium' : 'expanded';

    const isShortLandscape = isLandscape && safeHeight <= 760;
    const isVeryShortLandscape = isLandscape && safeHeight <= 690;

    let layoutPreset: LayoutPreset = 'phone';

    if (widthClass === 'expanded' && (safeWidth >= 1366 || shortSide >= 900)) {
      layoutPreset = 'tv';
    } else if (
      isLandscape &&
      ((widthClass === 'expanded' && aspectRatio >= 1.42) ||
        (widthClass === 'medium' && aspectRatio >= 1.48))
    ) {
      layoutPreset = 'wideTablet';
    } else if (widthClass === 'medium' || widthClass === 'expanded') {
      layoutPreset = 'tablet';
    }

    const widthBase =
      layoutPreset === 'tv'
        ? 1366
        : layoutPreset === 'wideTablet'
          ? 1180
          : layoutPreset === 'tablet'
            ? 1024
            : 420;

    const heightBase =
      layoutPreset === 'tv'
        ? 768
        : layoutPreset === 'wideTablet'
          ? 760
          : layoutPreset === 'tablet'
            ? 800
            : 800;

    const widthFactor = safeWidth / widthBase;
    const heightFactor = safeHeight / heightBase;
    const geometricFactor = Math.sqrt(widthFactor * heightFactor);

    const weightedBase = isLandscape
      ? widthFactor * 0.34 + heightFactor * 0.66
      : widthFactor * 0.52 + heightFactor * 0.48;

    const aspectBias = isLandscape
      ? clamp((aspectRatio - 1.35) * 0.02, -0.02, 0.02)
      : clamp((1.7 - aspectRatio) * 0.03, -0.02, 0.04);

    const shortLandscapePenalty = isLandscape
      ? clamp((780 - safeHeight) / 240, 0, layoutPreset === 'tv' ? 0.05 : 0.19)
      : 0;
    const veryWidePenalty = isLandscape
      ? clamp((aspectRatio - 1.78) * 0.09, 0, layoutPreset === 'tv' ? 0.04 : 0.13)
      : 0;
    const narrowPenalty = clamp((460 - shortSide) / 180, 0, 0.08);

    const blendedBase = weightedBase * 0.6 + geometricFactor * 0.4 + aspectBias;

    const scale = clamp(
      blendedBase - shortLandscapePenalty - veryWidePenalty - narrowPenalty,
      layoutPreset === 'tv' ? 0.92 : isLandscape ? 0.72 : 0.78,
      layoutPreset === 'tv' ? 1.18 : layoutPreset === 'wideTablet' ? 1.04 : 1.02,
    );

    const textScale = clamp(
      scale / Math.min(fontScale || 1, 1.15),
      layoutPreset === 'tv' ? 0.92 : isLandscape ? 0.7 : 0.76,
      layoutPreset === 'tv' ? 1.12 : 1.02,
    );

    const s = (value: number) => {
      const next = round(value * scale);
      return Number.isFinite(next) ? next : value;
    };

    const fs = (value: number, minFactor = 0.82, maxFactor = 1.06) => {
      const next = round(
        clamp(value * textScale, value * minFactor, value * maxFactor),
      );
      return Number.isFinite(next) ? next : value;
    };

    return {
      width: safeWidth,
      height: safeHeight,
      shortSide,
      longSide,
      aspectRatio,
      isLandscape,
      isShortLandscape,
      isVeryShortLandscape,
      widthClass,
      layoutPreset,
      scale,
      sizeScale: scale,
      textScale,
      styleKey: `${Math.round(safeWidth)}x${Math.round(safeHeight)}-${layoutPreset}-${widthClass}`,
      s,
      fs,
    };
  }, [fontScale, height, width]);
};

export default useAdaptiveLayout;
