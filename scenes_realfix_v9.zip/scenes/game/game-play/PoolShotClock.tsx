import React, {memo, useMemo} from 'react';

import Button from 'components/Button';
import Text from 'components/Text';
import View from 'components/View';

import useAdaptiveLayout from '../useAdaptiveLayout';

interface Props {
  originalCountdownTime?: number;
  currentCountdownTime: number;
  onPress?: () => void;
}

const SEGMENTS = 34;

const clamp = (value: number, min: number, max: number) =>
  Math.max(min, Math.min(max, value));

const PoolShotClock = ({
  originalCountdownTime = 40,
  currentCountdownTime,
  onPress,
}: Props) => {
  const adaptive = useAdaptiveLayout();

  const fitScale = useMemo(() => {
    if (!adaptive.isLandscape) {
      return clamp(adaptive.textScale, 0.72, 1);
    }

    const heightFit = clamp((adaptive.height - 90) / 260, 0.46, 1);
    const widthFit = clamp((adaptive.width - 120) / 820, 0.6, 1);
    return clamp(Math.min(adaptive.textScale, heightFit, widthFit), 0.46, 1);
  }, [adaptive.height, adaptive.isLandscape, adaptive.textScale, adaptive.width]);

  const segmentHeight = Math.round(36 * fitScale);
  const segmentWrapMinHeight = Math.round(40 * fitScale);
  const secondsFontSize = Math.round(26 * fitScale);
  const secondsMarginLeft = Math.round(8 * fitScale);
  const segmentRadius = Math.max(3, Math.round(5 * fitScale));
  const segmentMargin = Math.max(1, Math.round(1.5 * fitScale));

  const safeOriginal = Math.max(1, originalCountdownTime || 40);
  const safeCurrent = Math.max(0, currentCountdownTime);
  const progressMax = Math.max(safeOriginal, safeCurrent);

  const activeColor =
    safeCurrent <= 5 ? '#FF2D22' : safeCurrent <= 10 ? '#FFBE2F' : '#20E247';

  const litCount = useMemo(() => {
    return Math.max(0, Math.ceil((safeCurrent / progressMax) * SEGMENTS));
  }, [safeCurrent, progressMax]);

  return (
    <Button onPress={onPress} style={{width: '100%', paddingTop: 0, paddingBottom: 0}}>
      <View style={{width: '100%'}} direction={'row'} alignItems={'center'} justify={'between'}>
        <View
          flex={'1'}
          direction={'row'}
          justify={'between'}
          alignItems={'center'}
          style={{minHeight: segmentWrapMinHeight}}>
          {Array.from({length: SEGMENTS}, (_, index) => {
            const isLit = index < litCount;
            return (
              <View
                key={`clock-segment-${index}`}
                style={{
                  flex: 1,
                  height: segmentHeight,
                  marginHorizontal: segmentMargin,
                  borderRadius: segmentRadius,
                  backgroundColor: isLit ? activeColor : '#2A2B31',
                  opacity: isLit ? 1 : 0.98,
                }}
              />
            );
          })}
        </View>

        <Text color={activeColor} fontSize={secondsFontSize} fontWeight={'bold'} marginLeft={String(secondsMarginLeft)}>
          {`${safeCurrent}s`}
        </Text>
      </View>
    </Button>
  );
};

export default memo(PoolShotClock);
