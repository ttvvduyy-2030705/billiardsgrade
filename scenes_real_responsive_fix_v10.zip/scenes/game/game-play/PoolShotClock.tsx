import React, {memo, useMemo} from 'react';

import Button from 'components/Button';
import Text from 'components/Text';
import View from 'components/View';

import useAdaptiveLayout from '../useAdaptiveLayout';

interface Props {
  originalCountdownTime?: number;
  currentCountdownTime: number;
  onPress?: () => void;
}

const SEGMENTS = 34;
const clamp = (value: number, min: number, max: number) =>
  Math.max(min, Math.min(max, value));

const PoolShotClock = ({
  originalCountdownTime = 40,
  currentCountdownTime,
  onPress,
}: Props) => {
  const adaptive = useAdaptiveLayout();
  const scale = useMemo(() => {
    const heightScale = adaptive.height / 980;
    const widthScale = adaptive.width / 1360;
    const base = adaptive.isLandscape
      ? heightScale * 0.82 + widthScale * 0.18
      : widthScale * 0.55 + heightScale * 0.45;
    const ratioPenalty = adaptive.isLandscape
      ? clamp((adaptive.aspectRatio - 1.75) * 0.08, 0, 0.1)
      : 0;
    const shortPenalty = adaptive.isLandscape
      ? clamp((920 - adaptive.height) / 320, 0, 0.14)
      : 0;

    return clamp(base - ratioPenalty - shortPenalty, 0.52, adaptive.layoutPreset === 'tv' ? 1.18 : 0.92);
  }, [adaptive.aspectRatio, adaptive.height, adaptive.isLandscape, adaptive.layoutPreset, adaptive.width]);

  const isLargeDisplay = adaptive.layoutPreset === 'tv';
  const segmentHeight = Math.round((isLargeDisplay ? 72 : 26) * scale);
  const segmentWrapMinHeight = Math.round((isLargeDisplay ? 80 : 30) * scale);
  const secondsFontSize = Math.round((isLargeDisplay ? 44 : 18) * scale);
  const secondsMarginLeft = Math.round((isLargeDisplay ? 12 : 8) * scale);
  const segmentRadius = Math.max(3, Math.round((isLargeDisplay ? 6 : 4) * scale));
  const segmentMargin = Math.max(1, Math.round(2 * scale));

  const safeOriginal = Math.max(1, originalCountdownTime || 40);
  const safeCurrent = Math.max(0, currentCountdownTime);
  const progressMax = Math.max(safeOriginal, safeCurrent);

  const activeColor =
    safeCurrent <= 5 ? '#FF2D22' : safeCurrent <= 10 ? '#FFBE2F' : '#20E247';

  const litCount = useMemo(() => {
    return Math.max(0, Math.ceil((safeCurrent / progressMax) * SEGMENTS));
  }, [safeCurrent, progressMax]);

  return (
    <Button onPress={onPress} style={{width: '100%', paddingTop: 0, paddingBottom: 0}}>
      <View style={{width: '100%'}} direction={'row'} alignItems={'center'} justify={'between'}>
        <View
          flex={'1'}
          direction={'row'}
          justify={'between'}
          alignItems={'center'}
          style={{minHeight: segmentWrapMinHeight}}>
          {Array.from({length: SEGMENTS}, (_, index) => {
            const isLit = index < litCount;
            return (
              <View
                key={`clock-segment-${index}`}
                style={{
                  flex: 1,
                  height: segmentHeight,
                  marginHorizontal: segmentMargin,
                  borderRadius: segmentRadius,
                  backgroundColor: isLit ? activeColor : '#2A2B31',
                  opacity: isLit ? 1 : 0.98,
                }}
              />
            );
          })}
        </View>

        <Text
          color={activeColor}
          fontSize={String(secondsFontSize)}
          fontWeight={'bold'}
          marginLeft={String(secondsMarginLeft)}>
          {`${safeCurrent}s`}
        </Text>
      </View>
    </Button>
  );
};

export default memo(PoolShotClock);
