import {useMemo} from 'react';
import {PixelRatio, useWindowDimensions} from 'react-native';

export type WidthClass = 'compact' | 'medium' | 'expanded';
export type LayoutPreset = 'phone' | 'tablet' | 'wideTablet' | 'tv';

export type AdaptiveLayout = {
  width: number;
  height: number;
  shortSide: number;
  longSide: number;
  aspectRatio: number;
  isLandscape: boolean;
  isShortLandscape: boolean;
  isVeryShortLandscape: boolean;
  widthClass: WidthClass;
  layoutPreset: LayoutPreset;
  scale: number;
  sizeScale: number;
  textScale: number;
  styleKey: string;
  s: (value: number) => number;
  fs: (value: number, minFactor?: number, maxFactor?: number) => number;
};

const clamp = (value: number, min: number, max: number) =>
  Math.max(min, Math.min(max, value));

const round = (value: number) => PixelRatio.roundToNearestPixel(value);

export const useAdaptiveLayout = (): AdaptiveLayout => {
  const {width, height, fontScale} = useWindowDimensions();

  return useMemo(() => {
    const safeWidth = Number.isFinite(width) && width > 0 ? width : 1;
    const safeHeight = Number.isFinite(height) && height > 0 ? height : 1;
    const shortSide = Math.min(safeWidth, safeHeight);
    const longSide = Math.max(safeWidth, safeHeight);
    const aspectRatio = longSide / Math.max(shortSide, 1);
    const isLandscape = safeWidth >= safeHeight;

    const widthClass: WidthClass =
      safeWidth < 600 ? 'compact' : safeWidth < 960 ? 'medium' : 'expanded';

    const isShortLandscape = isLandscape && safeHeight <= 920;
    const isVeryShortLandscape = isLandscape && safeHeight <= 820;

    let layoutPreset: LayoutPreset = 'phone';

    if (widthClass === 'expanded' && (safeWidth >= 1600 || shortSide >= 900)) {
      layoutPreset = 'tv';
    } else if (
      isLandscape &&
      ((widthClass === 'expanded' && aspectRatio >= 1.45) ||
        (widthClass === 'medium' && aspectRatio >= 1.5))
    ) {
      layoutPreset = 'wideTablet';
    } else if (widthClass === 'medium' || widthClass === 'expanded') {
      layoutPreset = 'tablet';
    }

    const widthBase =
      layoutPreset === 'tv'
        ? 1600
        : layoutPreset === 'wideTablet'
          ? 1280
          : layoutPreset === 'tablet'
            ? 1080
            : 420;

    const heightBase =
      layoutPreset === 'tv'
        ? 900
        : layoutPreset === 'wideTablet'
          ? 900
          : layoutPreset === 'tablet'
            ? 920
            : 800;

    const shortBase =
      layoutPreset === 'tv' ? 900 : layoutPreset === 'phone' ? 420 : 720;

    const widthFactor = safeWidth / widthBase;
    const heightFactor = safeHeight / heightBase;
    const shortFactor = shortSide / shortBase;

    const targetBase = isLandscape
      ? heightFactor * 0.62 + shortFactor * 0.23 + widthFactor * 0.15
      : widthFactor * 0.42 + heightFactor * 0.38 + shortFactor * 0.2;

    const widePenalty = isLandscape
      ? clamp((aspectRatio - 1.72) * 0.11, 0, 0.18)
      : 0;
    const shortPenalty = isLandscape
      ? clamp((940 - safeHeight) / 420, 0, 0.2)
      : clamp((760 - safeHeight) / 260, 0, 0.12);
    const compactPenalty = widthClass === 'compact' ? 0.03 : 0;

    const minScale =
      layoutPreset === 'tv'
        ? 0.9
        : isVeryShortLandscape
          ? 0.56
          : isShortLandscape
            ? 0.6
            : layoutPreset === 'phone'
              ? 0.72
              : 0.7;

    const maxScale = layoutPreset === 'tv' ? 1.18 : 1.0;

    const scale = clamp(targetBase - widePenalty - shortPenalty - compactPenalty, minScale, maxScale);

    const fontLimiter = Math.min(fontScale || 1, 1.12);
    const textScale = clamp(
      scale / fontLimiter,
      Math.max(0.54, minScale - 0.02),
      layoutPreset === 'tv' ? 1.08 : 1.0,
    );

    const s = (value: number) => {
      const next = round(value * scale);
      return Number.isFinite(next) ? next : value;
    };

    const fs = (value: number, minFactor = 0.76, maxFactor = 1.0) => {
      const next = round(clamp(value * textScale, value * minFactor, value * maxFactor));
      return Number.isFinite(next) ? next : value;
    };

    return {
      width: safeWidth,
      height: safeHeight,
      shortSide,
      longSide,
      aspectRatio,
      isLandscape,
      isShortLandscape,
      isVeryShortLandscape,
      widthClass,
      layoutPreset,
      scale,
      sizeScale: scale,
      textScale,
      styleKey: `${Math.round(safeWidth)}x${Math.round(safeHeight)}-${layoutPreset}-${widthClass}-${isShortLandscape ? 'short' : 'regular'}`,
      s,
      fs,
    };
  }, [fontScale, height, width]);
};

export default useAdaptiveLayout;
